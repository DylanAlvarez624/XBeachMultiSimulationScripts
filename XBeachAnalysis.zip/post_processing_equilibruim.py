#!/usr/bin/env python3
"""
XBeach morphological quasi-equilibrium checker
"""

import pandas as pd
import numpy as np
from pathlib import Path

# ----------------------------------------------------------------------
# USER SETTINGS
# ----------------------------------------------------------------------
CSV_FILE = r"C:\Users\alvarezd2022\Documents\VisualStudioCode\XBeachAnalysis\results\SIM_001\postprocessing\morphological_volume.csv"

# Rule 1 – long-term average rate
LOOKBACK_AVG_HOURS   = 100
MAX_AVG_RATE_M3H     = 3.0

# Rule 2 – smoothed rate
SMOOTH_WINDOW_HOURS  = 6
MAX_SMOOTHED_M3H     = 5.0
SMOOTH_FRACTION_OK   = 0.85

# Rule 3 – total volume change
LOOKBACK_TOTAL_HOURS = 100
MAX_TOTAL_CHANGE_M3  = 300.0

# ----------------------------------------------------------------------
def check_quasi_equilibrium(csv_file: str) -> dict:
    df = pd.read_csv(csv_file)

    required = {"time_s", "net_volume_m3", "delta_net_volume_m3"}
    if not required.issubset(df.columns):
        raise ValueError(f"CSV must contain columns: {required}")

    dt_s = df["time_s"].diff().dropna().median()
    steps_per_hour = 3600 / dt_s
    print(f"Detected time step: {dt_s:.0f} s  →  {steps_per_hour:.1f} steps/hour")
    print(f"Total simulation length: {df['time_s'].iloc[-1]/3600:.1f} hours\n")

    df["rate_m3h"] = df["delta_net_volume_m3"] * (3600 / dt_s)

    # Rule 1
    n_steps_avg = min(int(LOOKBACK_AVG_HOURS * steps_per_hour), len(df) - 1)
    delta_v_avg = df["net_volume_m3"].iloc[-1] - df["net_volume_m3"].iloc[-n_steps_avg - 1]
    avg_rate = delta_v_avg / LOOKBACK_AVG_HOURS
    rule1_ok = abs(avg_rate) <= MAX_AVG_RATE_M3H

    # Rule 2
    n_smooth = max(1, int(SMOOTH_WINDOW_HOURS * steps_per_hour))
    df["rate_smooth"] = df["rate_m3h"].rolling(n_smooth, center=True, min_periods=1).mean()
    smooth_tail = df["rate_smooth"].iloc[-n_steps_avg:]
    fraction_ok = (smooth_tail.abs() <= MAX_SMOOTHED_M3H).mean()
    rule2_ok = fraction_ok >= SMOOTH_FRACTION_OK

    # Rule 3
    n_steps_total = min(int(LOOKBACK_TOTAL_HOURS * steps_per_hour), len(df) - 1)
    total_change = abs(df["net_volume_m3"].iloc[-1] - df["net_volume_m3"].iloc[-n_steps_total - 1])
    rule3_ok = total_change <= MAX_TOTAL_CHANGE_M3

    all_ok = rule1_ok and rule2_ok and rule3_ok

    # Print results
    print("=" * 65)
    print("QUASI-EQUILIBRIUM CHECK RESULTS")
    print("=" * 65)

    print(f"\nRule 1 – Average rate over last {LOOKBACK_AVG_HOURS} h")
    print(f"         |avg rate| = {abs(avg_rate):.2f} m³/h   (limit ≤ {MAX_AVG_RATE_M3H})")
    print(f"         → {'PASS' if rule1_ok else 'FAIL'}")

    print(f"\nRule 2 – Smoothed rate ({SMOOTH_WINDOW_HOURS} h rolling mean)")
    print(f"         Fraction of points ≤ {MAX_SMOOTHED_M3H} m³/h : {fraction_ok*100:.1f}%")
    print(f"         (required ≥ {SMOOTH_FRACTION_OK*100:.0f}%)")
    print(f"         → {'PASS' if rule2_ok else 'FAIL'}")

    print(f"\nRule 3 – Total |Δnet volume| over last {LOOKBACK_TOTAL_HOURS} h")
    print(f"         |ΔV| = {total_change:.1f} m³   (limit ≤ {MAX_TOTAL_CHANGE_M3})")
    print(f"         → {'PASS' if rule3_ok else 'FAIL'}")

    print("\n" + "=" * 65)
    if all_ok:
        print("VERDICT: Simulation IS at acceptable quasi-equilibrium")
    else:
        print("VERDICT: Simulation is NOT yet at acceptable quasi-equilibrium")
    print("=" * 65)

    return {
        "is_equilibrium": all_ok,
        "avg_rate_m3h": avg_rate,
        "smooth_fraction_ok": fraction_ok,
        "total_change_m3": total_change,
    }


if __name__ == "__main__":
    result = check_quasi_equilibrium(CSV_FILE)