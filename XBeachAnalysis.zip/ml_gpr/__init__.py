"""
Gaussian Process Regression package for XBeach SBW morphology results.

Objective: minimize total morphological change
    J = |erosion| + accretion
"""

__version__ = "0.1.0"
