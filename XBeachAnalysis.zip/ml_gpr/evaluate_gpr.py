"""
Evaluate a trained GPR bundle and plot J vs sbw_x for sample climates.
"""

from __future__ import annotations

from pathlib import Path

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from prepare_data import FEATURE_COLS, load_results, build_xy

PACKAGE_DIR = Path(__file__).resolve().parent
DEFAULT_DATA = PACKAGE_DIR / "example_master_results.csv"
BUNDLE_PATH = PACKAGE_DIR / "models" / "gpr_bundle.joblib"
FIG_DIR = PACKAGE_DIR / "figures"


def load_bundle(path: str | Path = BUNDLE_PATH):
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(
            f"Model bundle not found:\n{path}\n"
            "Run train_gpr.py first."
        )
    return joblib.load(path)


def predict_change(bundle, X_raw: np.ndarray):
    """Predict mean and std of total morphological change."""
    Xs = bundle["scaler"].transform(X_raw)
    mu, std = bundle["gp_change"].predict(Xs, return_std=True)
    return mu, std


def plot_j_vs_sbwx(
    bundle,
    climate: dict,
    sbw_x_grid: np.ndarray | None = None,
    truth_df: pd.DataFrame | None = None,
    out_path: Path | None = None,
):
    """
    Plot predicted J(sbw_x) for a fixed climate.

    climate keys: wave_angle, Hs, Tp, D50, sbw_length_y
    """
    if sbw_x_grid is None:
        sbw_x_grid = np.linspace(100.0, 220.0, 61)

    rows = []
    for x in sbw_x_grid:
        rows.append(
            [
                climate["wave_angle"],
                climate["Hs"],
                climate["Tp"],
                x,
                climate["D50"],
                climate["sbw_length_y"],
            ]
        )
    X = np.asarray(rows, dtype=float)
    mu, std = predict_change(bundle, X)

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(sbw_x_grid, mu, color="C0", lw=2, label="GP mean $J$")
    ax.fill_between(
        sbw_x_grid,
        mu - 1.96 * std,
        mu + 1.96 * std,
        color="C0",
        alpha=0.2,
        label="95% predictive interval",
    )

    # Overlay observed points from the same climate if provided
    if truth_df is not None:
        mask = (
            np.isclose(truth_df["wave_angle"], climate["wave_angle"])
            & np.isclose(truth_df["Hs"], climate["Hs"])
            & np.isclose(truth_df["Tp"], climate["Tp"])
            & np.isclose(truth_df["D50"], climate["D50"])
            & np.isclose(truth_df["sbw_length_y"], climate["sbw_length_y"])
        )
        sub = truth_df.loc[mask]
        if len(sub):
            ax.scatter(
                sub["sbw_x"],
                sub["total_change_m3"],
                color="k",
                s=30,
                zorder=5,
                label="Observed (same climate)",
            )

    i_best = int(np.argmin(mu))
    ax.axvline(
        sbw_x_grid[i_best],
        color="C3",
        ls="--",
        label=f"min $J$ at sbw_x = {sbw_x_grid[i_best]:.1f} m",
    )

    ax.set_xlabel("sbw_x (m)")
    ax.set_ylabel("Total morphological change $J$ (m³)")
    ax.set_title(
        f"J vs sbw_x | Hs={climate['Hs']} m, Tp={climate['Tp']} s, "
        f"angle={climate['wave_angle']}°, Ly={climate['sbw_length_y']} m"
    )
    ax.grid(True, ls=":")
    ax.legend(loc="best")
    fig.tight_layout()

    if out_path is not None:
        out_path = Path(out_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(out_path, dpi=140)
        print(f"Saved figure → {out_path}")

    plt.close(fig)
    return sbw_x_grid[i_best], float(mu[i_best])


def main():
    bundle = load_bundle()
    df = load_results(DEFAULT_DATA)

    # Overall residual check on full set (illustrative)
    X, _, _, y_change, _ = build_xy(df)
    mu, std = predict_change(bundle, X)
    rmse = float(np.sqrt(np.mean((mu - y_change) ** 2)))
    print(f"Full-data total_change RMSE (includes train): {rmse:.3f} m³")

    climate = {
        "wave_angle": 270.0,
        "Hs": 1.5,
        "Tp": 8.0,
        "D50": 0.0002,
        "sbw_length_y": 50.0,
    }
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    x_star, j_star = plot_j_vs_sbwx(
        bundle,
        climate,
        truth_df=df,
        out_path=FIG_DIR / "J_vs_sbwx_example.png",
    )
    print(f"Example climate optimum: sbw_x* = {x_star:.1f} m, J* ≈ {j_star:.2f} m³")


if __name__ == "__main__":
    main()
