"""
Recommend optimal cross-shore breakwater location (sbw_x)
that minimizes total morphological change:

    J = |erosion| + accretion

Usage examples
--------------
    # Use defaults (example climate, example-trained model)
    python optimize_sbw_x.py

    # Custom climate
    python optimize_sbw_x.py --Hs 2.0 --Tp 10 --wave-angle 255 --sbw-length-y 75

    # After training on real master_results.csv
    python optimize_sbw_x.py --bundle models/gpr_bundle.joblib --Hs 1.8
"""

from __future__ import annotations

import argparse
from pathlib import Path

import joblib
import numpy as np

PACKAGE_DIR = Path(__file__).resolve().parent
BUNDLE_PATH = PACKAGE_DIR / "models" / "gpr_bundle.joblib"


def load_bundle(path: str | Path = BUNDLE_PATH):
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(
            f"Model bundle not found:\n{path}\n"
            "Train first with:  python train_gpr.py"
        )
    return joblib.load(path)


def optimize_sbw_x(
    bundle,
    wave_angle: float,
    Hs: float,
    Tp: float,
    D50: float,
    sbw_length_y: float,
    sbw_x_min: float = 100.0,
    sbw_x_max: float = 220.0,
    n_grid: int = 121,
    kappa: float = 0.0,
):
    """
    Grid-search sbw_x for fixed climate / design parameters.

    Parameters
    ----------
    kappa :
        Risk aversion. kappa=0 → minimize predicted mean J.
        kappa>0 → minimize mean + kappa * std (prefer confident regions).

    Returns
    -------
    result : dict
    """
    grid = np.linspace(sbw_x_min, sbw_x_max, n_grid)
    X = np.column_stack(
        [
            np.full(n_grid, wave_angle),
            np.full(n_grid, Hs),
            np.full(n_grid, Tp),
            grid,
            np.full(n_grid, D50),
            np.full(n_grid, sbw_length_y),
        ]
    )
    Xs = bundle["scaler"].transform(X)

    # Primary objective from dedicated total-change GP
    mu_j, std_j = bundle["gp_change"].predict(Xs, return_std=True)
    score = mu_j + kappa * std_j
    i_best = int(np.argmin(score))

    # Also report erosion / accretion at the optimum
    mu_e, std_e = bundle["gp_erosion"].predict(
        Xs[i_best : i_best + 1], return_std=True
    )
    mu_a, std_a = bundle["gp_accretion"].predict(
        Xs[i_best : i_best + 1], return_std=True
    )

    return {
        "sbw_x_opt": float(grid[i_best]),
        "J_mean": float(mu_j[i_best]),
        "J_std": float(std_j[i_best]),
        "J_score": float(score[i_best]),
        "erosion_mean": float(mu_e[0]),
        "erosion_std": float(std_e[0]),
        "accretion_mean": float(mu_a[0]),
        "accretion_std": float(std_a[0]),
        "grid": grid,
        "J_mean_curve": mu_j,
        "J_std_curve": std_j,
        "kappa": kappa,
        "climate": {
            "wave_angle": wave_angle,
            "Hs": Hs,
            "Tp": Tp,
            "D50": D50,
            "sbw_length_y": sbw_length_y,
        },
    }


def print_result(result: dict):
    c = result["climate"]
    print("=" * 60)
    print("Optimal SBW cross-shore location")
    print("=" * 60)
    print("Climate / design (fixed):")
    print(f"  wave_angle   = {c['wave_angle']} deg")
    print(f"  Hs           = {c['Hs']} m")
    print(f"  Tp           = {c['Tp']} s")
    print(f"  D50          = {c['D50']} m")
    print(f"  sbw_length_y = {c['sbw_length_y']} m")
    print()
    print(f"Recommended sbw_x* = {result['sbw_x_opt']:.2f} m")
    print()
    print("Predicted total morphological change J = |E| + A:")
    print(f"  mean = {result['J_mean']:.3f} m³")
    print(f"  std  = {result['J_std']:.3f} m³")
    if result["kappa"] != 0:
        print(
            f"  score (mean + {result['kappa']}·std) = {result['J_score']:.3f}"
        )
    print()
    print("At sbw_x*:")
    print(
        f"  erosion   = {result['erosion_mean']:.3f} "
        f"± {result['erosion_std']:.3f} m³"
    )
    print(
        f"  accretion = {result['accretion_mean']:.3f} "
        f"± {result['accretion_std']:.3f} m³"
    )
    print("=" * 60)


def parse_args():
    p = argparse.ArgumentParser(
        description=(
            "Optimize sbw_x to minimize total morphological change "
            "using a trained GPR surrogate."
        )
    )
    p.add_argument(
        "--bundle",
        type=str,
        default=str(BUNDLE_PATH),
        help="Path to gpr_bundle.joblib",
    )
    p.add_argument("--wave-angle", type=float, default=270.0)
    p.add_argument("--Hs", type=float, default=1.5)
    p.add_argument("--Tp", type=float, default=8.0)
    p.add_argument("--D50", type=float, default=0.0002)
    p.add_argument("--sbw-length-y", type=float, default=50.0)
    p.add_argument("--sbw-x-min", type=float, default=100.0)
    p.add_argument("--sbw-x-max", type=float, default=220.0)
    p.add_argument(
        "--kappa",
        type=float,
        default=0.0,
        help="Risk term: minimize mean + kappa*std (0 = pure mean)",
    )
    return p.parse_args()


def main():
    args = parse_args()
    bundle = load_bundle(args.bundle)
    result = optimize_sbw_x(
        bundle,
        wave_angle=args.wave_angle,
        Hs=args.Hs,
        Tp=args.Tp,
        D50=args.D50,
        sbw_length_y=args.sbw_length_y,
        sbw_x_min=args.sbw_x_min,
        sbw_x_max=args.sbw_x_max,
        kappa=args.kappa,
    )
    print_result(result)


if __name__ == "__main__":
    main()
