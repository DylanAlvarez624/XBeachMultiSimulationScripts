"""
Train Gaussian Process models for erosion, accretion, and total change.

Saves a joblib bundle:
    models/gpr_bundle.joblib
containing:
    gp_erosion, gp_accretion, gp_change, scaler, feature_names, meta
"""

from __future__ import annotations

import json
from pathlib import Path

import joblib
import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, WhiteKernel, ConstantKernel

from prepare_data import (
    FEATURE_COLS,
    build_xy,
    fit_scaler,
    load_results,
    train_val_split,
)

# Default paths (relative to this package)
PACKAGE_DIR = Path(__file__).resolve().parent
DEFAULT_DATA = PACKAGE_DIR / "example_master_results.csv"
MODEL_DIR = PACKAGE_DIR / "models"
BUNDLE_PATH = MODEL_DIR / "gpr_bundle.joblib"


def make_gp(random_state: int = 42) -> GaussianProcessRegressor:
    """
    Matérn-like behaviour via RBF + white noise.
    ARD: one length-scale per feature (learned from data).
    """
    n_features = len(FEATURE_COLS)
    kernel = ConstantKernel(1.0, (1e-3, 1e3)) * RBF(
        length_scale=np.ones(n_features),
        length_scale_bounds=(1e-2, 1e2),
    ) + WhiteKernel(noise_level=1e-3, noise_level_bounds=(1e-8, 1e1))

    return GaussianProcessRegressor(
        kernel=kernel,
        normalize_y=True,
        n_restarts_optimizer=5,
        random_state=random_state,
        alpha=1e-10,
    )


def train(
    csv_path: str | Path = DEFAULT_DATA,
    bundle_path: str | Path = BUNDLE_PATH,
    test_size: float = 0.2,
    random_state: int = 42,
):
    df = load_results(csv_path)
    X, y_erosion, y_accretion, y_change, feature_names = build_xy(df)
    split = train_val_split(
        X, y_erosion, y_accretion, y_change,
        test_size=test_size,
        random_state=random_state,
    )
    scaler = fit_scaler(split["X_train"])
    X_train = scaler.transform(split["X_train"])
    X_val = scaler.transform(split["X_val"])

    print("Training GP for erosion...")
    gp_erosion = make_gp(random_state)
    gp_erosion.fit(X_train, split["y_erosion_train"])

    print("Training GP for accretion...")
    gp_accretion = make_gp(random_state + 1)
    gp_accretion.fit(X_train, split["y_accretion_train"])

    print("Training GP for total morphological change...")
    gp_change = make_gp(random_state + 2)
    gp_change.fit(X_train, split["y_change_train"])

    def metrics(gp, Xv, yv, name):
        pred = gp.predict(Xv)
        rmse = float(np.sqrt(np.mean((pred - yv) ** 2)))
        mae = float(np.mean(np.abs(pred - yv)))
        ss_res = np.sum((yv - pred) ** 2)
        ss_tot = np.sum((yv - np.mean(yv)) ** 2)
        r2 = float(1.0 - ss_res / ss_tot) if ss_tot > 0 else float("nan")
        print(f"  {name:12s}  RMSE={rmse:8.3f}  MAE={mae:8.3f}  R2={r2:6.3f}")
        return {"rmse": rmse, "mae": mae, "r2": r2}

    print("\nValidation metrics:")
    meta = {
        "n_train": int(len(split["X_train"])),
        "n_val": int(len(split["X_val"])),
        "feature_names": feature_names,
        "data_path": str(Path(csv_path).resolve()),
        "val_metrics": {
            "erosion": metrics(
                gp_erosion, X_val, split["y_erosion_val"], "erosion"
            ),
            "accretion": metrics(
                gp_accretion, X_val, split["y_accretion_val"], "accretion"
            ),
            "total_change": metrics(
                gp_change, X_val, split["y_change_val"], "total_change"
            ),
        },
    }

    bundle = {
        "gp_erosion": gp_erosion,
        "gp_accretion": gp_accretion,
        "gp_change": gp_change,
        "scaler": scaler,
        "feature_names": feature_names,
        "meta": meta,
    }

    bundle_path = Path(bundle_path)
    bundle_path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(bundle, bundle_path)

    meta_path = bundle_path.with_suffix(".json")
    meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")

    print(f"\nSaved model bundle → {bundle_path}")
    print(f"Saved metrics      → {meta_path}")
    return bundle


def main():
    train()


if __name__ == "__main__":
    main()
