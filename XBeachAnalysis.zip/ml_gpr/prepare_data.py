"""
Load and prepare master_results for GPR training.

Expected columns (same as run_simulations.py output):
    simulation_id, wave_angle, Hs, Tp, sbw_x, D50, sbw_length_y,
    total_erosion_m3, total_accretion_m3

Erosion is expected to be <= 0 (as produced by the post-processor).
Total morphological change:
    J = |erosion| + accretion
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# Feature columns used by the GP
FEATURE_COLS = [
    "wave_angle",
    "Hs",
    "Tp",
    "sbw_x",
    "D50",
    "sbw_length_y",
]

TARGET_EROSION = "total_erosion_m3"
TARGET_ACCRETION = "total_accretion_m3"


def load_results(csv_path: str | Path) -> pd.DataFrame:
    """Load master_results CSV and add the objective column."""
    path = Path(csv_path)
    if not path.is_file():
        raise FileNotFoundError(f"Results file not found:\n{path}")

    df = pd.read_csv(path)

    required = FEATURE_COLS + [TARGET_EROSION, TARGET_ACCRETION]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Missing columns in results CSV:\n{missing}")

    # Drop incomplete rows
    df = df.dropna(subset=required).copy()

    # Objective: total morphological change
    # erosion is typically negative → abs recovers volume lost
    df["total_change_m3"] = (
        np.abs(df[TARGET_EROSION].astype(float))
        + df[TARGET_ACCRETION].astype(float)
    )

    return df


def build_xy(df: pd.DataFrame):
    """
    Return feature matrix X and targets.

    Returns
    -------
    X : ndarray, shape (n, n_features)
    y_erosion, y_accretion, y_change : 1-d arrays
    feature_names : list of str
    """
    X = df[FEATURE_COLS].to_numpy(dtype=float)
    y_erosion = df[TARGET_EROSION].to_numpy(dtype=float)
    y_accretion = df[TARGET_ACCRETION].to_numpy(dtype=float)
    y_change = df["total_change_m3"].to_numpy(dtype=float)
    return X, y_erosion, y_accretion, y_change, list(FEATURE_COLS)


def train_val_split(
    X,
    y_erosion,
    y_accretion,
    y_change,
    test_size: float = 0.2,
    random_state: int = 42,
):
    """Hold-out split (shared indices for all targets)."""
    indices = np.arange(len(X))
    train_idx, val_idx = train_test_split(
        indices,
        test_size=test_size,
        random_state=random_state,
    )

    def take(arr, idx):
        return arr[idx]

    return {
        "X_train": take(X, train_idx),
        "X_val": take(X, val_idx),
        "y_erosion_train": take(y_erosion, train_idx),
        "y_erosion_val": take(y_erosion, val_idx),
        "y_accretion_train": take(y_accretion, train_idx),
        "y_accretion_val": take(y_accretion, val_idx),
        "y_change_train": take(y_change, train_idx),
        "y_change_val": take(y_change, val_idx),
        "train_idx": train_idx,
        "val_idx": val_idx,
    }


def fit_scaler(X_train: np.ndarray) -> StandardScaler:
    """Standardize features (important for RBF / Matérn GPs)."""
    scaler = StandardScaler()
    scaler.fit(X_train)
    return scaler


def main():
    """Quick self-test on the example CSV."""
    example = Path(__file__).resolve().parent / "example_master_results.csv"
    df = load_results(example)
    X, ye, ya, yc, names = build_xy(df)
    split = train_val_split(X, ye, ya, yc)
    scaler = fit_scaler(split["X_train"])

    print(f"Loaded {len(df)} rows from {example.name}")
    print(f"Features: {names}")
    print(f"Train: {len(split['X_train'])}  Val: {len(split['X_val'])}")
    print(
        f"total_change_m3  min={df.total_change_m3.min():.2f}  "
        f"max={df.total_change_m3.max():.2f}  "
        f"mean={df.total_change_m3.mean():.2f}"
    )
    print(f"Scaler means: {np.round(scaler.mean_, 4)}")


if __name__ == "__main__":
    main()
