"""
End-to-end demo on example_master_results.csv:

    1. Train GPs
    2. Evaluate + plot J vs sbw_x
    3. Optimize sbw_x for an example climate
"""

from pathlib import Path

from train_gpr import train
from evaluate_gpr import load_bundle, plot_j_vs_sbwx
from optimize_sbw_x import optimize_sbw_x, print_result
from prepare_data import load_results

PACKAGE_DIR = Path(__file__).resolve().parent
DATA = PACKAGE_DIR / "example_master_results.csv"
FIG_DIR = PACKAGE_DIR / "figures"


def main():
    print("\n=== 1. Train ===\n")
    train(csv_path=DATA)

    print("\n=== 2. Evaluate / plot ===\n")
    bundle = load_bundle()
    df = load_results(DATA)
    climate = {
        "wave_angle": 270.0,
        "Hs": 1.5,
        "Tp": 8.0,
        "D50": 0.0002,
        "sbw_length_y": 50.0,
    }
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    x_star, j_star = plot_j_vs_sbwx(
        bundle,
        climate,
        truth_df=df,
        out_path=FIG_DIR / "J_vs_sbwx_example.png",
    )
    print(f"Plot optimum: sbw_x* = {x_star:.1f} m, J* ≈ {j_star:.2f} m³")

    print("\n=== 3. Optimize ===\n")
    result = optimize_sbw_x(
        bundle,
        wave_angle=270.0,
        Hs=1.5,
        Tp=8.0,
        D50=0.0002,
        sbw_length_y=50.0,
    )
    print_result(result)

    print("\nDemo complete.")
    print(f"Models : {PACKAGE_DIR / 'models' / 'gpr_bundle.joblib'}")
    print(f"Figure : {FIG_DIR / 'J_vs_sbwx_example.png'}")


if __name__ == "__main__":
    main()
