"""
===============================================================
XBeach 2D Post-Processing and Beach Profile Analysis
===============================================================

Purpose
-------
This script analyzes the results of a 2D XBeach simulation stored
in xboutput.nc.

The script produces:
    1. 2D animated bed change (Δzb)
    2. Accretion / erosion volume versus time
    3. Final 2D bed elevation figure
    4. 2D bed-change figure
    5. Cross-shore beach profile
    6. Animated cross-shore beach profile
    7. CSV file containing morphological volume data

The cross-shore profile is extracted from the center of the
alongshore domain by default.

Usage
-----
Standalone (uses default SIMULATION_DIR below):

    python post_processing_2D.py

Called by the batch runner:

    python post_processing_2D.py --simulation-dir "C:\\...\\results\\SIM_001"

Python
------
Designed for Python 3.13.

Required packages
-----------------
    numpy
    xarray
    netCDF4
    matplotlib
    pillow

Install with:

    python -m pip install numpy xarray netCDF4 matplotlib pillow

For MP4 animation instead of GIF, FFmpeg must also be installed
and available on PATH.

===============================================================
"""


# =============================================================
# 1. IMPORT REQUIRED LIBRARIES
# =============================================================

import argparse
import os
import sys

import numpy as np
import xarray as xr

import matplotlib.pyplot as plt
import matplotlib.animation as animation


# =============================================================
# 2. USER CONFIGURATION  (defaults – overridable via CLI)
# =============================================================
#
# Change settings in this section rather than modifying the rest
# of the script.
#


# -------------------------------------------------------------
# Default XBeach simulation directory
# (used only when --simulation-dir is NOT supplied)
# -------------------------------------------------------------

DEFAULT_SIMULATION_DIR = (
    r"C:\Users\alvarezd2022\Documents\VisualStudioCode\XBeachAnalysis\Test"
)


# -------------------------------------------------------------
# Animation settings
# -------------------------------------------------------------

# Frames to skip.
#
# STRIDE = 1  → use every available time step
# STRIDE = 2  → use every second time step
# STRIDE = 5  → use every fifth time step

STRIDE = 1

# Frames per second for GIF / MP4
FPS = 8

# Resolution of saved figures and animations
DPI = 120


# -------------------------------------------------------------
# Animation file type
# -------------------------------------------------------------
#
# Use:
#     ".gif"   (requires Pillow)
# or:
#     ".mp4"   (requires FFmpeg)
#

ANIMATION_EXTENSION = ".gif"


# -------------------------------------------------------------
# Bed elevation color map
# -------------------------------------------------------------

ELEVATION_CMAP = "terrain"


# -------------------------------------------------------------
# Cross-section location
# -------------------------------------------------------------
#
# "middle"  → automatically extracts the center row of the model
#
# A numerical value can also be used:
#     CROSS_SECTION = 125.0
# In that case, the row closest to y = 125 m is selected.
#

CROSS_SECTION = "middle"


# -------------------------------------------------------------
# Toggle animations
# -------------------------------------------------------------

MAKE_PROFILE_ANIMATION = True
MAKE_BED_ANIMATION = True


# -------------------------------------------------------------
# Optional fixed elevation limits
# -------------------------------------------------------------
#
# Set these to None for automatic limits.
#
# Example:
#     ELEVATION_MIN = -20
#     ELEVATION_MAX = 5
#

ELEVATION_MIN = None
ELEVATION_MAX = None


# =============================================================
# 3. COMMAND-LINE ARGUMENTS
# =============================================================

def parse_arguments():
    """
    Accept an optional --simulation-dir so the batch runner can
    point the post-processor at any completed simulation folder.
    """
    parser = argparse.ArgumentParser(
        description="XBeach 2D post-processing and beach profile analysis."
    )

    parser.add_argument(
        "--simulation-dir",
        type=str,
        default=None,
        help=(
            "Path to the simulation folder that contains xboutput.nc. "
            "If omitted, the DEFAULT_SIMULATION_DIR from the script is used."
        ),
    )

    return parser.parse_args()


# =============================================================
# 4. HELPER FUNCTION — FIND VARIABLES
# =============================================================

def find_variable(dataset, candidates):
    """
    Search the XBeach dataset for the first matching variable.

    Parameters
    ----------
    dataset : xarray.Dataset
        Open XBeach NetCDF dataset.
    candidates : list
        Possible variable names.

    Returns
    -------
    str or None
        Matching variable name.
    """
    for name in candidates:
        if name in dataset.variables:
            return name
    return None


# =============================================================
# 5. MAIN POST-PROCESSING LOGIC
# =============================================================

def run_postprocessing(simulation_dir: str) -> None:
    """
    Perform the full post-processing workflow for one simulation.
    """

    simulation_dir = os.path.abspath(simulation_dir)
    netcdf_file = os.path.join(simulation_dir, "xboutput.nc")
    output_dir = os.path.join(simulation_dir, "postprocessing")

    os.makedirs(output_dir, exist_ok=True)

    print("=" * 65)
    print("XBeach Post-Processing")
    print("=" * 65)
    print()
    print("Simulation directory:")
    print(simulation_dir)
    print()
    print("NetCDF file:")
    print(netcdf_file)
    print()
    print("Output directory:")
    print(output_dir)
    print()

    # ---------------------------------------------------------
    # Check that the NetCDF file exists
    # ---------------------------------------------------------

    if not os.path.isfile(netcdf_file):
        raise FileNotFoundError(
            "\nXBeach output file was not found:\n"
            f"{netcdf_file}\n\n"
            "Check the simulation directory."
        )

    # ---------------------------------------------------------
    # Load XBeach NetCDF data
    # ---------------------------------------------------------

    print("Loading XBeach NetCDF output...")

    with xr.open_dataset(netcdf_file, engine="netcdf4") as ds:

        print("NetCDF file loaded.")
        print()

        # =====================================================
        # Identify XBeach variables
        # =====================================================

        zb_name = find_variable(ds, ["zb", "zb_mean"])
        zs_name = find_variable(ds, ["zs", "zs_mean"])
        x_name = find_variable(ds, ["globalx", "x"])
        y_name = find_variable(ds, ["globaly", "y"])

        # Identify time dimension
        time_name = None
        if zb_name is not None:
            for candidate in ["globaltime", "meantime", "time"]:
                if candidate in ds[zb_name].dims:
                    time_name = candidate
                    break

        # =====================================================
        # Verify required variables
        # =====================================================

        if zb_name is None:
            raise ValueError(
                "Could not find bed elevation variable.\n"
                "Expected one of: zb, zb_mean"
            )

        if x_name is None:
            raise ValueError(
                "Could not find X coordinate.\n"
                "Expected one of: globalx, x"
            )

        if y_name is None:
            raise ValueError(
                "Could not find Y coordinate.\n"
                "Expected one of: globaly, y"
            )

        if time_name is None:
            raise ValueError(
                "Could not determine the XBeach time dimension."
            )

        print("Detected variables:")
        print(f"    Bed elevation : {zb_name}")
        print(f"    Water surface : {zs_name}")
        print(f"    X coordinate  : {x_name}")
        print(f"    Y coordinate  : {y_name}")
        print(f"    Time          : {time_name}")
        print()

        # =====================================================
        # Extract basic data
        # =====================================================

        zb = ds[zb_name]

        if zs_name is not None:
            zs = ds[zs_name]
        else:
            zs = None
            print("WARNING: Water surface variable was not found.")

        x = ds[x_name].values
        y = ds[y_name].values
        time = ds[time_name].values

        # =====================================================
        # Identify spatial dimensions
        # =====================================================

        print("Bed elevation dimensions:")
        print(zb.dims)
        print()

        time_dim = time_name
        x_dim = None
        y_dim = None

        for dim in zb.dims:
            if dim == time_dim:
                continue
            if dim.lower() in ["nx", "x"]:
                x_dim = dim
            elif dim.lower() in ["ny", "y"]:
                y_dim = dim

        remaining_dims = [dim for dim in zb.dims if dim != time_dim]

        if x_dim is None and len(remaining_dims) >= 1:
            # X is normally the last spatial dimension
            x_dim = remaining_dims[-1]

        if y_dim is None and len(remaining_dims) >= 2:
            # Y is normally the first spatial dimension
            y_dim = remaining_dims[-2]

        print("Detected spatial dimensions:")
        print(f"    X dimension: {x_dim}")
        print(f"    Y dimension: {y_dim}")
        print()

        # =====================================================
        # Reorder bed data → time × y × x
        # =====================================================

        zb_ordered = zb.transpose(time_dim, y_dim, x_dim)
        zb_values = zb_ordered.values

        if zs is not None:
            try:
                zs_ordered = zs.transpose(time_dim, y_dim, x_dim)
                zs_values = zs_ordered.values
            except ValueError:
                print(
                    "WARNING: Water surface dimensions do not match "
                    "bed elevation dimensions."
                )
                zs_values = None
        else:
            zs_values = None

        # =====================================================
        # Apply frame stride
        # =====================================================

        zb_values = zb_values[::STRIDE]
        time_values = time[::STRIDE]

        if zs_values is not None:
            zs_values = zs_values[::STRIDE]

        n_frames = len(time_values)

        print(f"Number of animation frames: {n_frames}")
        print()

        # =====================================================
        # Create 2D X/Y grid
        # =====================================================

        if x.ndim == 1:
            x_1d = x
        else:
            x_1d = x[0, :]

        if y.ndim == 1:
            y_1d = y
        else:
            y_1d = y[:, 0]

        X, Y = np.meshgrid(x_1d, y_1d)

        # =====================================================
        # Initial and final bed
        # =====================================================

        zb_initial = zb_values[0]
        zb_final = zb_values[-1]

        # =====================================================
        # Calculate bed change
        # =====================================================

        dzb = zb_values - zb_initial

        # =====================================================
        # Calculate cell area
        # =====================================================

        if len(x_1d) > 1:
            dx = np.abs(np.mean(np.diff(x_1d)))
        else:
            dx = 1.0

        if len(y_1d) > 1:
            dy = np.abs(np.mean(np.diff(y_1d)))
        else:
            dy = 1.0

        cell_area = dx * dy

        print("Grid spacing:")
        print(f"    dx = {dx:.4f} m")
        print(f"    dy = {dy:.4f} m")
        print(f"    Cell area = {cell_area:.4f} m²")
        print()

        # =====================================================
        # Calculate accretion and erosion volumes
        # =====================================================

        accretion_volume = []
        erosion_volume = []
        net_volume = []

        for frame in dzb:
            positive_change = np.where(frame > 0, frame, 0.0)
            negative_change = np.where(frame < 0, frame, 0.0)

            accretion = np.nansum(positive_change) * cell_area
            erosion = np.nansum(negative_change) * cell_area
            net = np.nansum(frame) * cell_area

            accretion_volume.append(accretion)
            erosion_volume.append(erosion)
            net_volume.append(net)

        accretion_volume = np.asarray(accretion_volume)
        erosion_volume = np.asarray(erosion_volume)
        net_volume = np.asarray(net_volume)

        # Change in net volume since the previous output time step.
        # First entry is set to 0 (no previous step).
        delta_net_volume = np.diff(net_volume, prepend=net_volume[0])
        delta_net_volume[0] = 0.0

        # =====================================================
        # Save volume data to CSV
        # =====================================================

        csv_path = os.path.join(output_dir, "morphological_volume.csv")

        volume_data = np.column_stack(
            (
                time_values,
                accretion_volume,
                erosion_volume,
                net_volume,
                delta_net_volume,
            )
        )

        np.savetxt(
            csv_path,
            volume_data,
            delimiter=",",
            header=(
                "time_s,"
                "accretion_volume_m3,"
                "erosion_volume_m3,"
                "net_volume_m3,"
                "delta_net_volume_m3"
            ),
            comments="",
        )

        print(f"Saved volume data:\n{csv_path}")
        print()

        # =====================================================
        # Determine elevation limits
        # =====================================================

        if ELEVATION_MIN is None:
            elevation_min = np.nanmin(zb_values)
        else:
            elevation_min = ELEVATION_MIN

        if ELEVATION_MAX is None:
            elevation_max = np.nanmax(zb_values)
        else:
            elevation_max = ELEVATION_MAX

        # =====================================================
        # FIGURE — Final 2D bed elevation
        # =====================================================

        print("Creating final bed elevation figure...")

        fig_final, ax_final = plt.subplots(figsize=(10, 7))

        final_mesh = ax_final.pcolormesh(
            X,
            Y,
            zb_final,
            cmap=ELEVATION_CMAP,
            vmin=elevation_min,
            vmax=elevation_max,
            shading="auto",
        )

        cbar = fig_final.colorbar(final_mesh, ax=ax_final)
        cbar.set_label("Bed elevation (m)")

        ax_final.set_xlabel("Cross-shore distance (m)")
        ax_final.set_ylabel("Alongshore distance (m)")
        ax_final.set_title(
            f"Final XBeach Bed Elevation — t = {time_values[-1]:.1f} s"
        )
        ax_final.set_aspect("equal")

        final_bed_path = os.path.join(output_dir, "final_bed_elevation.png")
        fig_final.tight_layout()
        fig_final.savefig(final_bed_path, dpi=DPI)
        plt.close(fig_final)

        print(f"Saved:\n{final_bed_path}")

        # =====================================================
        # FIGURE — 2D bed change
        # =====================================================

        print("Creating bed-change figure...")

        fig_change, ax_change = plt.subplots(figsize=(10, 7))

        max_change = np.nanmax(np.abs(dzb[-1]))
        if max_change == 0:
            max_change = 1.0

        change_mesh = ax_change.pcolormesh(
            X,
            Y,
            dzb[-1],
            cmap="RdBu_r",
            vmin=-max_change,
            vmax=max_change,
            shading="auto",
        )

        cbar = fig_change.colorbar(change_mesh, ax=ax_change)
        cbar.set_label("Bed elevation change Δzb (m)")

        ax_change.set_xlabel("Cross-shore distance (m)")
        ax_change.set_ylabel("Alongshore distance (m)")
        ax_change.set_title("Final Morphological Change")
        ax_change.set_aspect("equal")

        change_path = os.path.join(output_dir, "bed_change.png")
        fig_change.tight_layout()
        fig_change.savefig(change_path, dpi=DPI)
        plt.close(fig_change)

        print(f"Saved:\n{change_path}")

        # =====================================================
        # FIGURE — Accretion / erosion volume
        # =====================================================

        print("Creating volume-change figure...")

        fig_volume, ax_volume = plt.subplots(figsize=(10, 6))

        ax_volume.plot(
            time_values, accretion_volume, linewidth=2, label="Accretion"
        )
        ax_volume.plot(
            time_values, erosion_volume, linewidth=2, label="Erosion"
        )
        ax_volume.plot(
            time_values,
            net_volume,
            linewidth=2,
            linestyle="--",
            label="Net volume",
        )
        ax_volume.axhline(0, linewidth=0.8)

        ax_volume.set_xlabel("Time (s)")
        ax_volume.set_ylabel("Volume (m³)")
        ax_volume.set_title("Accretion and Erosion Volume")
        ax_volume.grid(True, linestyle=":")
        ax_volume.legend()

        volume_plot_path = os.path.join(output_dir, "volume_change.png")
        fig_volume.tight_layout()
        fig_volume.savefig(volume_plot_path, dpi=DPI)
        plt.close(fig_volume)

        print(f"Saved:\n{volume_plot_path}")

        # =====================================================
        # Determine cross-shore transect
        # =====================================================

        print()
        print("Selecting cross-shore transect...")

        number_of_y_points = len(y_1d)

        if isinstance(CROSS_SECTION, str):
            if CROSS_SECTION.lower() == "middle":
                mid_y_index = number_of_y_points // 2
            else:
                raise ValueError(
                    "CROSS_SECTION must be 'middle' or a numerical Y coordinate."
                )
        else:
            requested_y = float(CROSS_SECTION)
            mid_y_index = int(np.argmin(np.abs(y_1d - requested_y)))

        selected_y = y_1d[mid_y_index]

        print(f"Cross-section index: {mid_y_index}")
        print(f"Alongshore location: y = {selected_y:.3f} m")
        print()

        # =====================================================
        # Extract cross-shore profiles
        # =====================================================

        profile_initial = zb_values[0, mid_y_index, :]
        profile_final = zb_values[-1, mid_y_index, :]
        profile_series = zb_values[:, mid_y_index, :]

        if zs_values is not None:
            water_series = zs_values[:, mid_y_index, :]
        else:
            water_series = None

        # =====================================================
        # FIGURE — Cross-shore profile
        # =====================================================

        print("Creating cross-shore profile figure...")

        fig_profile, ax_profile = plt.subplots(figsize=(12, 7))

        ax_profile.plot(
            x_1d,
            profile_initial,
            linestyle="--",
            linewidth=1.5,
            label="Initial Bed Level",
        )
        ax_profile.plot(
            x_1d,
            profile_final,
            linewidth=2,
            label="Final Bed Level",
        )

        erosion_mask = profile_final < profile_initial
        ax_profile.fill_between(
            x_1d,
            profile_initial,
            profile_final,
            where=erosion_mask,
            alpha=0.4,
            label="Erosion",
        )

        accretion_mask = profile_final > profile_initial
        ax_profile.fill_between(
            x_1d,
            profile_initial,
            profile_final,
            where=accretion_mask,
            alpha=0.4,
            label="Accretion",
        )

        ax_profile.set_xlabel("Cross-shore Distance (m)")
        ax_profile.set_ylabel("Elevation Relative to Datum (m)")
        ax_profile.set_title(
            "Cross-Shore Beach Profile\n"
            f"Alongshore Location y = {selected_y:.2f} m"
        )
        ax_profile.grid(True, linestyle=":")
        ax_profile.legend(loc="best")

        profile_path = os.path.join(output_dir, "cross_shore_profile.png")
        fig_profile.tight_layout()
        fig_profile.savefig(profile_path, dpi=DPI)
        plt.close(fig_profile)

        print(f"Saved:\n{profile_path}")

        # =====================================================
        # ANIMATED 2D bed change (Δzb)
        # =====================================================

        if MAKE_BED_ANIMATION:
            print()
            print("Creating 2D bed-change animation...")

            # Symmetric colour limits from the maximum absolute
            # change across all frames so the scale is fixed.
            max_abs_change = np.nanmax(np.abs(dzb))
            if max_abs_change == 0:
                max_abs_change = 1.0

            fig_anim, ax_anim = plt.subplots(figsize=(10, 8))

            bed_mesh = ax_anim.pcolormesh(
                X,
                Y,
                dzb[0],
                cmap="RdBu_r",
                vmin=-max_abs_change,
                vmax=max_abs_change,
                shading="auto",
            )

            colorbar = fig_anim.colorbar(bed_mesh, ax=ax_anim)
            colorbar.set_label("Bed elevation change Δzb (m)")

            ax_anim.set_xlabel("Cross-shore distance (m)")
            ax_anim.set_ylabel("Alongshore distance (m)")
            ax_anim.set_aspect("equal")

            title_anim = ax_anim.set_title(
                f"XBeach Bed Change — t = {time_values[0]:.1f} s"
            )

            def update_bed(frame_index):
                bed_mesh.set_array(dzb[frame_index].ravel())
                title_anim.set_text(
                    f"XBeach Bed Change — t = {time_values[frame_index]:.1f} s"
                )
                return bed_mesh, title_anim

            bed_animation = animation.FuncAnimation(
                fig_anim,
                update_bed,
                frames=n_frames,
                interval=1000 / FPS,
                blit=False,
            )

            bed_animation_path = os.path.join(
                output_dir, "bed_change_animation" + ANIMATION_EXTENSION
            )

            print(f"Rendering {n_frames} frames...")

            if ANIMATION_EXTENSION.lower() == ".gif":
                writer = animation.PillowWriter(fps=FPS)
            elif ANIMATION_EXTENSION.lower() == ".mp4":
                writer = animation.FFMpegWriter(fps=FPS)
            else:
                raise ValueError(
                    "ANIMATION_EXTENSION must be '.gif' or '.mp4'"
                )

            bed_animation.save(bed_animation_path, writer=writer, dpi=DPI)
            plt.close(fig_anim)

            print(f"Saved:\n{bed_animation_path}")

        # =====================================================
        # ANIMATED cross-shore profile
        # =====================================================

        if MAKE_PROFILE_ANIMATION:
            print()
            print("Creating cross-shore profile animation...")

            fig_profile_anim, ax_profile_anim = plt.subplots(figsize=(12, 7))

            profile_min = np.nanmin(profile_series)
            profile_max = np.nanmax(profile_series)

            if water_series is not None:
                water_max = np.nanmax(water_series)
                profile_max = max(profile_max, water_max)

            profile_range = profile_max - profile_min
            if profile_range == 0:
                profile_range = 1.0

            profile_padding = 0.1 * profile_range

            ax_profile_anim.set_xlim(x_1d.min(), x_1d.max())
            ax_profile_anim.set_ylim(
                profile_min - profile_padding,
                profile_max + profile_padding,
            )

            ax_profile_anim.set_xlabel("Cross-shore Distance (m)")
            ax_profile_anim.set_ylabel("Elevation Relative to Datum (m)")
            ax_profile_anim.grid(True, linestyle=":")

            ax_profile_anim.plot(
                x_1d,
                profile_initial,
                linestyle="--",
                linewidth=1.5,
                label="Initial Bed Level",
            )

            line_bed, = ax_profile_anim.plot(
                [], [], linewidth=2, label="Evolving Bed Level"
            )

            if water_series is not None:
                line_water, = ax_profile_anim.plot(
                    [], [], linewidth=1.5, label="Water Surface"
                )
            else:
                line_water = None

            water_fill = [None]

            profile_title = ax_profile_anim.set_title("", pad=15)
            ax_profile_anim.legend(loc="upper right")

            def update_profile(frame_index):
                current_bed = profile_series[frame_index]
                line_bed.set_data(x_1d, current_bed)

                if water_series is not None:
                    current_water = water_series[frame_index]
                    line_water.set_data(x_1d, current_water)

                    if water_fill[0] is not None:
                        water_fill[0].remove()

                    water_fill[0] = ax_profile_anim.fill_between(
                        x_1d,
                        current_bed,
                        current_water,
                        where=(current_water > current_bed),
                        alpha=0.3,
                    )

                profile_title.set_text(
                    "XBeach Cross-Shore Profile Evolution\n"
                    f"y = {selected_y:.2f} m    "
                    f"Time = {time_values[frame_index]:.1f} s"
                )

                if water_series is not None:
                    return line_bed, line_water, water_fill[0], profile_title
                else:
                    return line_bed, profile_title

            profile_animation = animation.FuncAnimation(
                fig_profile_anim,
                update_profile,
                frames=n_frames,
                interval=1000 / FPS,
                blit=False,
            )

            profile_animation_path = os.path.join(
                output_dir,
                "cross_shore_profile_animation" + ANIMATION_EXTENSION,
            )

            print(f"Rendering {n_frames} profile frames...")

            if ANIMATION_EXTENSION.lower() == ".gif":
                profile_writer = animation.PillowWriter(fps=FPS)
            elif ANIMATION_EXTENSION.lower() == ".mp4":
                profile_writer = animation.FFMpegWriter(fps=FPS)
            else:
                raise ValueError(
                    "ANIMATION_EXTENSION must be '.gif' or '.mp4'"
                )

            profile_animation.save(
                profile_animation_path, writer=profile_writer, dpi=DPI
            )
            plt.close(fig_profile_anim)

            print(f"Saved:\n{profile_animation_path}")

        # =====================================================
        # Final summary
        # =====================================================

        print()
        print("=" * 65)
        print("XBeach POST-PROCESSING COMPLETE")
        print("=" * 65)
        print()
        print(f"Simulation duration: {time_values[-1]:.2f} s")
        print(f"Final accretion volume: {accretion_volume[-1]:.4f} m³")
        print(f"Final erosion volume: {erosion_volume[-1]:.4f} m³")
        print(f"Final net volume change: {net_volume[-1]:.4f} m³")
        print()
        print("Cross-section:")
        print(f"    Alongshore position: y = {selected_y:.3f} m")
        print()
        print("Output files:")
        print(f"    {output_dir}")
        print()
        print("=" * 65)


# =============================================================
# 6. ENTRY POINT
# =============================================================

def main():
    args = parse_arguments()

    if args.simulation_dir is not None:
        simulation_dir = args.simulation_dir
    else:
        simulation_dir = DEFAULT_SIMULATION_DIR

    try:
        run_postprocessing(simulation_dir)
    except Exception as exc:
        print()
        print("POST-PROCESSING FAILED")
        print(exc)
        sys.exit(1)


if __name__ == "__main__":
    main()
