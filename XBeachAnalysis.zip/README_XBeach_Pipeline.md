# XBeach 2D Simulation Pipeline

Clean, consistent versions of the three core scripts.

## Scripts

| File | Role |
|------|------|
| `generate_2D_setup_SBW.py` | Builds bathymetry + SBW + XBeach input files for one simulation |
| `run_simulations.py` | Sequential batch controller (generate → XBeach → post-process → results) |
| `post_processing_2D.py` | Reads `xboutput.nc`, produces figures, animations, and morphological volumes |
| `simulations.csv` | Example input matrix |

## What was fixed

1. **Post-processor now accepts `--simulation-dir`**  
   The batch runner can correctly point it at each simulation folder.

2. **Scope / indentation bug removed**  
   The cross-shore profile animation and final summary now live inside the data-loading block, so all variables remain in scope.

3. **Cleaner structure**  
   Post-processing logic is wrapped in a `run_postprocessing()` function. All three scripts share the same expected interfaces.

## How to run on your machine

1. Place the three Python scripts where you want them (or update the paths inside `run_simulations.py`).

2. Edit the configuration sections at the top of each script so the paths match your folders:

   - `BASE_DIR`
   - `GENERATOR_SCRIPT`
   - `POSTPROCESSING_SCRIPT`
   - `TEMPLATE_DIR`
   - `INPUT_MATRIX`

3. Create (or edit) `simulations.csv` with the columns:

   ```
   simulation_id,wave_angle,Hs,Tp,sbw_x,sbw_y
   ```

4. Run the batch:

   ```bat
   python run_simulations.py
   ```

5. Results appear in:

   - `results/SIM_001/`, `results/SIM_002/`, …
   - `master_results.csv` (erosion & accretion volumes)

## Standalone post-processing

If you already have a finished simulation folder containing `xboutput.nc`:

```bat
python post_processing_2D.py --simulation-dir "C:\path\to\results\SIM_001"
```

Or simply edit `DEFAULT_SIMULATION_DIR` inside the script and run without arguments.

## Required packages

```bat
python -m pip install numpy xarray netCDF4 matplotlib pillow pandas scipy xbTools
```

FFmpeg is only needed if you set `ANIMATION_EXTENSION = ".mp4"`.
