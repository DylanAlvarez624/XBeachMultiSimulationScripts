"""
===============================================================
Generate one complete 2D XBeach simulation from simulations.csv
===============================================================

The script:
    1. Reads one simulation from the input matrix.
    2. Builds the plain synthetic beach (no breakwater) with a
       dry beach landward of shoreline_x.
    3. Creates the XBeach computational grid from that plain beach.
    4. Refines the cross-shore grid through the SBW envelope.
    5. Extends the grid seaward and laterally.
    6. Snaps the submerged breakwater onto whole cells of the
       final grid (bathymetry crest + non-erodible layer share
       one mask).
    7. Copies the XBeach installation/template into the simulation
       folder.
    8. Writes the simulation-specific XBeach input files.
    9. Saves diagnostic figures and realized SBW geometry.

This script DOES NOT:
    - Start XBeach.
    - Wait for XBeach.
    - Run post-processing.
    - Write the master results CSV.

Those tasks are handled by run_simulations.py.

Requires:
    Python 3.13
    numpy
    scipy
    matplotlib
    pandas
    xbTools

Coordinate convention:
    X = cross-shore
    Y = alongshore

SBW convention:
    sbw_x        = requested breakwater centroid, cross-shore
    sbw_y        = breakwater centroid, alongshore (domain centre)
    sbw_length_y = requested breakwater alongshore length

The requested SBW size is snapped to an integer number of cells
on the final grid. Treat the realized width/length/centroid in
simulation_info.txt as the actual structure, not the request.
"""


# ============================================================
# IMPORTS
# ============================================================

import argparse
import os
import shutil
import sys

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from scipy import interpolate

from xbTools.grid.creation import xgrid, ygrid
from xbTools.grid.extension import seaward_extend, lateral_extend
from xbTools.xbeachtools import XBeachModelSetup


# ============================================================
# USER CONFIGURATION
# ============================================================

# Location of the simulation input matrix.
INPUT_MATRIX = (
    r"C:\Users\alvarezd2022\Documents\VisualStudioCode"
    r"\XBeachAnalysis\simulations.csv"
)

# XBeach installation/template folder.
#
# This folder should contain the XBeach executable and all
# required supporting files.
TEMPLATE_DIR = (
    r"C:\Users\alvarezd2022\Documents\VisualStudioCode"
    r"\XBeachAnalysis\XBeach_1.24.6057_Halloween_win64_netcdf"
)

# ------------------------------------------------------------
# Synthetic beach configuration
# ------------------------------------------------------------

Lx = 500.0
Ly = 500.0

dx_raw = 5.0
dy_raw = 5.0

depth_offshore = -10.0
beach_slope = 1.0 / 50.0
max_elevation = 5.0

# Dry beach (Option A): shoreline fixed inside the domain so that
# a landward strip with z > 0 exists. Total domain length Lx is
# unchanged.
#
#   shoreline_x = cross-shore location of z = 0 (m)
#   dry beach   ≈ Lx - shoreline_x
#
shoreline_x = 400.0

# ------------------------------------------------------------
# Submerged breakwater configuration
# ------------------------------------------------------------

ADD_BREAKWATER = True

SBW_WIDTH_X = 25.0       # requested cross-shore width (m)

# Alongshore centroid is always placed at the centre of the domain.
# Alongshore length (sbw_length_y) comes from the input matrix.

BW_CREST_LEVEL = -1.0    # m relative to SWL
NE_THICKNESS = 10.0      # erodible sand thickness outside the structure

# ------------------------------------------------------------
# SBW-band grid refinement
#
# xbTools xgrid() is kept for CFL (coarse cells in deep water,
# dxmin near the shoreline). Without extra refinement the SBW
# sits in ~11–13 m cells, i.e. two cells across 25 m.
#
# Force dx ≈ DX_SBW through the envelope of possible SBW
# positions so every run uses the same grid and a 25 m crest
# is 10 cells wide.
# ------------------------------------------------------------

DX_SBW = 2.5             # target dx inside the SBW envelope (m)
SBW_REFINE_XMIN = 80.0   # seaward edge of refined band (m)
SBW_REFINE_XMAX = 240.0  # shoreward edge of refined band (m)
GRID_MAXFAC = 1.15       # max adjacent-cell size ratio in transitions


# ============================================================
# COMMAND-LINE ARGUMENTS
# ============================================================

def parse_arguments():
    """
    Read the simulation number and output directory from the
    command line.

    Example:

        python generate_2D_setup_SBW.py ^
            --simulation 1 ^
            --output "C:\\...\\results\\SIM_001"
    """
    parser = argparse.ArgumentParser(
        description="Generate one XBeach 2D simulation."
    )

    parser.add_argument(
        "--simulation",
        type=int,
        required=True,
        help="simulation_id from simulations.csv",
    )

    parser.add_argument(
        "--output",
        type=str,
        required=True,
        help="Output directory for this simulation",
    )

    return parser.parse_args()


# ============================================================
# READ SIMULATION MATRIX
# ============================================================

def load_simulation(simulation_number):
    """
    Read simulations.csv and return the requested simulation.
    """
    if not os.path.isfile(INPUT_MATRIX):
        raise FileNotFoundError(
            f"Simulation matrix not found:\n{INPUT_MATRIX}"
        )

    simulation_matrix = pd.read_csv(INPUT_MATRIX)

    required_columns = [
        "simulation_id",
        "wave_angle",
        "Hs",
        "Tp",
        "sbw_x",
        "D50",
        "sbw_length_y",
    ]

    missing_columns = [
        column
        for column in required_columns
        if column not in simulation_matrix.columns
    ]

    if missing_columns:
        raise ValueError(
            "The simulation matrix is missing these columns:\n"
            + "\n".join(missing_columns)
        )

    simulation = simulation_matrix[
        simulation_matrix["simulation_id"] == simulation_number
    ]

    if simulation.empty:
        raise ValueError(
            f"Simulation {simulation_number} was not found in:\n"
            f"{INPUT_MATRIX}"
        )

    if len(simulation) > 1:
        raise ValueError(
            f"Simulation {simulation_number} appears more than once "
            "in the input matrix."
        )

    simulation = simulation.iloc[0]

    simulation_id = int(simulation["simulation_id"])
    wave_angle = float(simulation["wave_angle"])
    Hs = float(simulation["Hs"])
    Tp = float(simulation["Tp"])
    sbw_x = float(simulation["sbw_x"])
    D50 = float(simulation["D50"])
    sbw_length_y = float(simulation["sbw_length_y"])

    # Alongshore centroid is fixed at the centre of the domain
    sbw_y = Ly / 2.0

    return (
        simulation_id,
        wave_angle,
        Hs,
        Tp,
        sbw_x,
        sbw_y,
        D50,
        sbw_length_y,
    )


# ============================================================
# BUILD RAW BATHYMETRY  (plain beach, no SBW)
# ============================================================

def build_bathymetry():
    """
    Build the initial synthetic beach bathymetry.

    The beach is:
        - Lx m cross-shore, Ly m alongshore
        - linearly sloped at beach_slope
        - uniform alongshore
        - shoreline (z = 0) at shoreline_x
        - dry beach (z > 0) from shoreline_x to Lx,
          capped at max_elevation

    Offshore of the shoreline the profile continues at the
    same slope down to depth_offshore (or the seaward boundary).

    The submerged breakwater is NOT inserted here. The
    computational grid must not depend on the structure.
    """
    nx = int(Lx / dx_raw) + 1
    ny = int(Ly / dy_raw) + 1

    x = np.linspace(0.0, Lx, nx)
    y = np.linspace(0.0, Ly, ny)

    # z = 0 at shoreline_x; positive landward, negative seaward
    z_profile = beach_slope * (x - shoreline_x)
    z_profile = np.clip(z_profile, depth_offshore, max_elevation)

    bathy = np.tile(z_profile, (ny, 1))

    return x, y, bathy


# ============================================================
# SAVE RAW BATHYMETRY FIGURE
# ============================================================

def save_input_bathymetry_plot(x, y, bathy, output_directory):
    """Save the raw input bathymetry figure."""
    figure_path = os.path.join(output_directory, "input_bathy.png")

    plt.figure()
    plt.pcolor(x, y, bathy, shading="auto")
    plt.colorbar(label="z [m]")
    plt.xlabel("x [m]")
    plt.ylabel("y [m]")
    plt.title("Input bathymetry (plain beach)")
    plt.axis("scaled")
    plt.savefig(figure_path, dpi=150, bbox_inches="tight")
    plt.close()


# ============================================================
# CROSS-SHORE REFINEMENT IN THE SBW ENVELOPE
# ============================================================

def _geometric_transition(x_fine, x_coarse, dx_fine, dx_coarse, maxfac=1.15):
    """
    Interior + coarse-end points of a geometric cell-size
    transition from dx_fine at x_fine to dx_coarse at x_coarse.

    x_fine itself is not included (it already belongs to the
    refined band). The last point is exactly x_coarse.
    """
    x_fine = float(x_fine)
    x_coarse = float(x_coarse)
    dx_fine = float(dx_fine)
    dx_coarse = float(max(dx_coarse, dx_fine))

    distance = abs(x_coarse - x_fine)
    sign = np.sign(x_coarse - x_fine)

    if distance < 0.5 * dx_fine:
        return np.array([x_coarse], dtype=float)

    best = None
    for n in range(1, 80):
        r = (dx_coarse / dx_fine) ** (1.0 / n)
        r = min(max(r, 1.0 / maxfac), maxfac)
        sizes = dx_fine * r ** np.arange(1, n + 1)
        err = abs(sizes.sum() - distance) + 0.2 * abs(sizes[-1] - dx_coarse)
        if best is None or err < best[0]:
            best = (err, n, r, sizes)

    sizes = best[3] * (distance / best[3].sum())
    points = x_fine + sign * np.cumsum(sizes)
    points[-1] = x_coarse
    return points.astype(float)


def refine_cross_shore_grid(
    xgr,
    xmin=SBW_REFINE_XMIN,
    xmax=SBW_REFINE_XMAX,
    dx_target=DX_SBW,
    maxfac=GRID_MAXFAC,
):
    """
    Keep the xbTools variable grid, but force dx = dx_target
    on [xmin, xmax], with geometric transitions (maxfac) so
    adjacent cells do not jump in size.

    Shoreward of xmax the native xgrid is kept once it is
    as fine as the grown transition (it already goes to dxmin
    at the shoreline).
    """
    xgr = np.unique(np.asarray(xgr, dtype=float))
    if xgr.size < 2:
        return xgr

    x0 = float(xgr[0])
    x_end = float(xgr[-1])
    dx_native = np.diff(xgr)
    x_centers = 0.5 * (xgr[:-1] + xgr[1:])
    dx_offshore = float(dx_native[0])

    n_band = max(1, int(round((xmax - xmin) / dx_target)))
    fine = np.linspace(xmin, xmax, n_band + 1)

    seaward = _geometric_transition(
        xmin, x0, dx_target, dx_offshore, maxfac
    )

    shoreward_pts = []
    x = float(xmax)
    prev_dx = float(dx_target)
    joined_native = False
    for _ in range(10000):
        grown = prev_dx * maxfac
        native = float(
            np.interp(
                x,
                x_centers,
                dx_native,
                left=dx_native[0],
                right=dx_native[-1],
            )
        )
        if grown >= native * 0.98:
            native_rest = xgr[xgr > x + 1e-8]
            shoreward_pts.extend(native_rest.tolist())
            joined_native = True
            break

        remaining = x_end - x
        if remaining <= grown * 1.25:
            if remaining >= 0.45 * dx_target:
                shoreward_pts.append(x_end)
            elif shoreward_pts:
                shoreward_pts[-1] = x_end
            else:
                shoreward_pts.append(x_end)
            break

        x = x + grown
        shoreward_pts.append(x)
        prev_dx = grown

    if not joined_native and (not shoreward_pts or shoreward_pts[-1] < x_end - 1e-8):
        shoreward_pts.append(x_end)

    shoreward = np.asarray(shoreward_pts, dtype=float)

    x_new = np.unique(
        np.concatenate(
            [
                np.atleast_1d(seaward),
                fine,
                np.atleast_1d(shoreward),
            ]
        )
    )
    return x_new


# ============================================================
# CREATE XBEACH GRID
# ============================================================

def create_xbeach_grid(x, y, bathy):
    """
    Convert the plain-beach bathymetry into the XBeach grid.

    The grid is:
        - refined near the shoreline by xbTools xgrid
        - forced to DX_SBW through the SBW envelope
        - interpolated from the plain beach only
    """
    xgr, _ = xgrid(x, bathy[0, :], dxmin=2)
    xgr = refine_cross_shore_grid(xgr)
    ygr = ygrid(y)

    interp_func = interpolate.RegularGridInterpolator(
        (y, x),
        bathy,
        method="linear",
        bounds_error=False,
        fill_value=None,
    )

    xgr2d, ygr2d = np.meshgrid(xgr, ygr)
    zgr = interp_func((ygr2d, xgr2d))

    return xgr2d, ygr2d, zgr


# ============================================================
# SAVE REGRIDDED BATHYMETRY FIGURE
# ============================================================

def save_regridded_bathymetry_plot(xgr2d, ygr2d, zgr, output_directory):
    """Save the bathymetry after interpolation onto the XBeach grid."""
    figure_path = os.path.join(output_directory, "regridded_bathy.png")

    plt.figure()
    plt.pcolor(xgr2d, ygr2d, zgr, shading="auto")
    plt.colorbar(label="z [m]")
    plt.xlabel("x [m]")
    plt.ylabel("y [m]")
    plt.title("Regridded bathymetry (plain beach)")
    plt.axis("scaled")
    plt.savefig(figure_path, dpi=150, bbox_inches="tight")
    plt.close()


# ============================================================
# EXTEND XBEACH GRID
# ============================================================

def extend_grid(xgr2d, ygr2d, zgr):
    """
    Extend the grid seaward and laterally.
    These settings are retained from the working generator.
    """
    xgr2d, ygr2d, zgr = seaward_extend(
        xgr2d, ygr2d, zgr, slope=1 / 20, depth=-20
    )
    xgr2d, ygr2d, zgr = lateral_extend(xgr2d, ygr2d, zgr, n=5)
    return xgr2d, ygr2d, zgr


# ============================================================
# SAVE EXTENDED BATHYMETRY FIGURE
# ============================================================

def save_extended_bathymetry_plot(xgr2d, ygr2d, zgr, output_directory):
    """Save the final extended bathymetry."""
    figure_path = os.path.join(output_directory, "extended_bathy.png")

    plt.figure()
    plt.pcolor(xgr2d, ygr2d, zgr, shading="auto")
    plt.colorbar(label="z [m]")
    plt.xlabel("x [m]")
    plt.ylabel("y [m]")
    plt.title("Extended XBeach grid with SBW")
    plt.axis("scaled")
    plt.savefig(figure_path, dpi=150, bbox_inches="tight")
    plt.close()


# ============================================================
# SAVE GRID RESOLUTION FIGURE
# ============================================================

def save_grid_resolution_plot(xgr2d, ygr2d, output_directory):
    """Save dx(x) and dy(y) of the final computational grid."""
    figure_path = os.path.join(output_directory, "grid_resolution.png")

    x1d = np.asarray(xgr2d[0, :], dtype=float)
    y1d = np.asarray(ygr2d[:, 0], dtype=float)
    dx = np.diff(x1d)
    dy = np.diff(y1d)
    x_mid = 0.5 * (x1d[:-1] + x1d[1:])
    y_mid = 0.5 * (y1d[:-1] + y1d[1:])

    fig, axes = plt.subplots(2, 1, figsize=(8, 6))

    axes[0].plot(x_mid, dx, ".-", color="C0")
    axes[0].axvline(SBW_REFINE_XMIN, color="0.4", ls="--", lw=0.8)
    axes[0].axvline(SBW_REFINE_XMAX, color="0.4", ls="--", lw=0.8)
    axes[0].axhline(DX_SBW, color="C1", ls=":", lw=0.8, label=f"DX_SBW = {DX_SBW} m")
    axes[0].set_xlabel("x [m]")
    axes[0].set_ylabel("dx [m]")
    axes[0].set_title("Cross-shore grid spacing")
    axes[0].legend(loc="upper right")
    axes[0].grid(True, alpha=0.3)

    axes[1].plot(y_mid, dy, ".-", color="C2")
    axes[1].set_xlabel("y [m]")
    axes[1].set_ylabel("dy [m]")
    axes[1].set_title("Alongshore grid spacing")
    axes[1].grid(True, alpha=0.3)

    fig.tight_layout()
    fig.savefig(figure_path, dpi=150, bbox_inches="tight")
    plt.close(fig)


# ============================================================
# SNAP SBW TO WHOLE CELLS
# ============================================================

def _cell_faces(coord):
    """Face coordinates from a monotonically increasing centre array."""
    coord = np.asarray(coord, dtype=float)
    faces = np.empty(coord.size + 1, dtype=float)
    faces[1:-1] = 0.5 * (coord[:-1] + coord[1:])
    faces[0] = coord[0] - 0.5 * (coord[1] - coord[0])
    faces[-1] = coord[-1] + 0.5 * (coord[-1] - coord[-2])
    return faces


def _local_spacing(coord, centre, half_window=4):
    """Mean spacing of cells neighbouring `centre`."""
    coord = np.asarray(coord, dtype=float)
    index = int(np.argmin(np.abs(coord - centre)))
    i0 = max(0, index - half_window)
    i1 = min(coord.size - 1, index + half_window)
    if i1 <= i0:
        return float(np.mean(np.diff(coord))) if coord.size > 1 else 1.0
    return float(np.mean(np.diff(coord[i0 : i1 + 1])))


def _best_block_start(coord, faces, n_cells, target_centre):
    """
    Index of the n_cells block whose face-to-face centroid is
    closest to target_centre.
    """
    best_i = 0
    best_score = np.inf
    n_options = coord.size - n_cells + 1
    if n_options < 1:
        raise ValueError(
            f"Cannot place {n_cells} cells on a {coord.size}-point axis."
        )
    for i in range(n_options):
        centroid = 0.5 * (faces[i] + faces[i + n_cells])
        score = abs(centroid - target_centre)
        if score < best_score:
            best_score = score
            best_i = i
    return best_i


def snap_sbw_mask(xgr2d, ygr2d, sbw_x, sbw_y, width_x, length_y):
    """
    Select a contiguous rectangular block of cells whose
    face-to-face size is as close as possible to the requested
    width/length and whose centroid is as close as possible to
    (sbw_x, sbw_y).
    """
    x1d = np.asarray(xgr2d[0, :], dtype=float)
    y1d = np.asarray(ygr2d[:, 0], dtype=float)

    faces_x = _cell_faces(x1d)
    faces_y = _cell_faces(y1d)

    dx_local = _local_spacing(x1d, sbw_x)
    dy_local = _local_spacing(y1d, sbw_y)

    n_x = max(1, int(round(width_x / dx_local)))
    n_y = max(1, int(round(length_y / dy_local)))

    i0 = _best_block_start(x1d, faces_x, n_x, sbw_x)
    j0 = _best_block_start(y1d, faces_y, n_y, sbw_y)

    mask = np.zeros(xgr2d.shape, dtype=bool)
    mask[j0 : j0 + n_y, i0 : i0 + n_x] = True

    geometry = {
        "n_x": n_x,
        "n_y": n_y,
        "dx_local": dx_local,
        "dy_local": dy_local,
        "requested_width": float(width_x),
        "requested_length": float(length_y),
        "requested_sbw_x": float(sbw_x),
        "requested_sbw_y": float(sbw_y),
        "realized_width": float(faces_x[i0 + n_x] - faces_x[i0]),
        "realized_length": float(faces_y[j0 + n_y] - faces_y[j0]),
        "realized_sbw_x": float(0.5 * (faces_x[i0] + faces_x[i0 + n_x])),
        "realized_sbw_y": float(0.5 * (faces_y[j0] + faces_y[j0 + n_y])),
        "x_min": float(faces_x[i0]),
        "x_max": float(faces_x[i0 + n_x]),
        "y_min": float(faces_y[j0]),
        "y_max": float(faces_y[j0 + n_y]),
        "n_cells": int(n_x * n_y),
    }
    return mask, geometry


def insert_breakwater(xgr2d, ygr2d, zgr, sbw_x, sbw_y, sbw_length_y):
    """
    Stamp the SBW onto the final grid.

    Inside the snapped cell block:
        bed is raised to the crest (never lowered)
        non-erodible thickness = 0

    Everywhere else:
        non-erodible thickness = NE_THICKNESS
    """
    ne_field = np.ones_like(zgr) * NE_THICKNESS
    z_out = np.array(zgr, copy=True)

    if not ADD_BREAKWATER:
        return z_out, ne_field, None

    mask, geometry = snap_sbw_mask(
        xgr2d,
        ygr2d,
        sbw_x,
        sbw_y,
        SBW_WIDTH_X,
        sbw_length_y,
    )

    z_out[mask] = np.maximum(z_out[mask], BW_CREST_LEVEL)
    ne_field[mask] = 0.0

    envelope_min = sbw_x - SBW_WIDTH_X / 2.0
    envelope_max = sbw_x + SBW_WIDTH_X / 2.0
    if envelope_min < SBW_REFINE_XMIN or envelope_max > SBW_REFINE_XMAX:
        print(
            "WARNING: requested SBW envelope "
            f"[{envelope_min:.1f}, {envelope_max:.1f}] m "
            "is not fully inside the refined x-band "
            f"[{SBW_REFINE_XMIN}, {SBW_REFINE_XMAX}] m. "
            "Realized width may differ from 25 m."
        )

    return z_out, ne_field, geometry


# ============================================================
# SAVE NON-ERODIBLE LAYER FIGURE
# ============================================================

def save_ne_layer_plot(xgr2d, ygr2d, ne_field, output_directory):
    """Save the non-erodible layer thickness."""
    figure_path = os.path.join(output_directory, "ne_layer.png")

    plt.figure()
    plt.pcolor(xgr2d, ygr2d, ne_field, shading="auto")
    plt.colorbar(label="thickness [m]")
    plt.xlabel("x [m]")
    plt.ylabel("y [m]")
    plt.title("Non-erodible layer thickness")
    plt.axis("scaled")
    plt.savefig(figure_path, dpi=150, bbox_inches="tight")
    plt.close()


# ============================================================
# COPY XBEACH TEMPLATE
# ============================================================

def copy_xbeach_template(output_directory):
    """
    Copy the XBeach installation/template into the simulation
    directory.

    This happens BEFORE xb_setup.write_model() so that the
    simulation-specific files generated by xbTools cannot be
    overwritten by generic template files.
    """
    if not os.path.isdir(TEMPLATE_DIR):
        raise FileNotFoundError(
            f"XBeach template directory not found:\n{TEMPLATE_DIR}"
        )

    shutil.copytree(
        TEMPLATE_DIR,
        output_directory,
        dirs_exist_ok=True,
    )

    print("XBeach template copied to:")
    print(output_directory)


# ============================================================
# BUILD XBEACH MODEL
# ============================================================

def build_xbeach_model(xgr2d, ygr2d, zgr, ne_field, Hs, Tp, wave_angle, D50):
    """
    Create the XBeachModelSetup object.
    Wave parameters and sediment diameter come from the simulation matrix.
    """
    xb_setup = XBeachModelSetup("500m x 250m simple beach slope test")

    # Grid
    xb_setup.set_grid(xgr2d, ygr2d, zgr, posdwn=-1, alfa=0)

    # Non-erodible bed
    xb_setup.set_nebed(ne_field)

    # Friction
    xb_setup.set_friction(np.ones_like(zgr))

    # Waves
    TSTOP = 5184000
    RT = 3600   # 60 minutes per wave realization
    n_rec = TSTOP // RT   # Total number of wave records

    xb_setup.set_waves(
    "jonstable",
    {
        "Hm0": [Hs] * n_rec,
        "Tp": [Tp] * n_rec,
        "gammajsp": [3.3] * n_rec,
        "s": [20] * n_rec,
        "mainang": [wave_angle] * n_rec,
        "duration": [RT] * n_rec,
        "dtbc": [1] * n_rec,
    },
)

    # XBeach parameters

    xb_setup.set_params(
    {
        "Wavemodel": "surfbeat",
        "morphology": 1,
        "struct": 1,
        "ne_layer": "ne_bed.dep",
        "D50": D50,
        "bedfriccoef": 0.02,          # ← change if desired
        "tstop": 5184000,                # ← change this
        "zs0": 0,

        # ---- ADD / MODIFY THE FOLLOWING ----
        "morfac": 50,                 # morphological acceleration
        "front": "abs_2d",
        "back": "wall",
        "left": "wall",
        "right": "wall",
        "facua": 0.1,                 # optional
        "porosity": 0.4,              # optional (default is usually fine)
        # ------------------------------------

        "nglobalvar": ["zb", "zs", "H"],
        "npointvar": ["zs", "H"],
        "nmeanvar": ["zb"],
    }
)

    return xb_setup


# ============================================================
# WRITE MODEL FILES
# ============================================================

def write_model_files(xb_setup, output_directory):
    """Write all simulation-specific XBeach files."""
    xb_setup.write_model(output_directory)

    print("\nXBeach model input files written to:")
    print(output_directory)


# ============================================================
# WRITE SIMULATION INFORMATION
# ============================================================

def write_simulation_info(
    output_directory,
    simulation_id,
    wave_angle,
    Hs,
    Tp,
    sbw_x,
    sbw_y,
    D50,
    sbw_length_y,
    sbw_geometry=None,
):
    """
    Save a small text file describing the simulation.
    Useful when inspecting individual simulation folders later.
    """
    info_path = os.path.join(output_directory, "simulation_info.txt")

    with open(info_path, "w", encoding="utf-8") as file:
        file.write("XBeach Simulation Information\n")
        file.write("=============================\n\n")
        file.write(f"simulation_id = {simulation_id}\n")
        file.write(f"wave_angle = {wave_angle}\n")
        file.write(f"Hs = {Hs}\n")
        file.write(f"Tp = {Tp}\n")
        file.write(f"sbw_x = {sbw_x}  (requested)\n")
        file.write(f"sbw_y = {sbw_y}  (domain centre, requested)\n")
        file.write(f"D50 = {D50}\n")
        file.write(f"sbw_length_y = {sbw_length_y}  (requested)\n")
        file.write("\nBeach profile\n")
        file.write(f"Lx = {Lx} m\n")
        file.write(f"Ly = {Ly} m\n")
        file.write(f"shoreline_x = {shoreline_x} m  (z = 0)\n")
        file.write(f"dry_beach_width ≈ {Lx - shoreline_x} m\n")
        file.write(f"beach_slope = 1/{1.0 / beach_slope:.0f}\n")
        file.write(f"depth_offshore = {depth_offshore} m\n")
        file.write(f"max_elevation = {max_elevation} m\n")
        file.write("\nRequested SBW dimensions\n")
        file.write(f"cross-shore width = {SBW_WIDTH_X} m\n")
        file.write(f"alongshore length = {sbw_length_y} m\n")
        file.write(f"crest level = {BW_CREST_LEVEL} m\n")
        file.write("\nGrid refinement\n")
        file.write(f"DX_SBW = {DX_SBW} m\n")
        file.write(
            f"refine band x = {SBW_REFINE_XMIN} – {SBW_REFINE_XMAX} m\n"
        )
        file.write(f"GRID_MAXFAC = {GRID_MAXFAC}\n")

        if sbw_geometry is not None:
            g = sbw_geometry
            file.write("\nRealized SBW (use these as the actual structure)\n")
            file.write(f"n_x = {g['n_x']}\n")
            file.write(f"n_y = {g['n_y']}\n")
            file.write(f"n_cells = {g['n_cells']}\n")
            file.write(f"dx_local = {g['dx_local']:.4f} m\n")
            file.write(f"dy_local = {g['dy_local']:.4f} m\n")
            file.write(f"realized_width = {g['realized_width']:.4f} m\n")
            file.write(f"realized_length = {g['realized_length']:.4f} m\n")
            file.write(f"realized_sbw_x = {g['realized_sbw_x']:.4f} m\n")
            file.write(f"realized_sbw_y = {g['realized_sbw_y']:.4f} m\n")
            file.write(f"x_min = {g['x_min']:.4f} m\n")
            file.write(f"x_max = {g['x_max']:.4f} m\n")
            file.write(f"y_min = {g['y_min']:.4f} m\n")
            file.write(f"y_max = {g['y_max']:.4f} m\n")

    if sbw_geometry is not None:
        csv_path = os.path.join(output_directory, "sbw_geometry.csv")
        pd.DataFrame([sbw_geometry]).to_csv(csv_path, index=False)


def print_sbw_geometry(geometry):
    """Print realized vs requested SBW size."""
    if geometry is None:
        return
    print("\nSBW snapped to computational grid:")
    print(
        f"    cells      : {geometry['n_x']} (x) x {geometry['n_y']} (y)"
        f"  = {geometry['n_cells']}"
    )
    print(
        f"    width      : {geometry['realized_width']:.3f} m"
        f"  (requested {geometry['requested_width']:.3f} m)"
    )
    print(
        f"    length     : {geometry['realized_length']:.3f} m"
        f"  (requested {geometry['requested_length']:.3f} m)"
    )
    print(
        f"    centroid x : {geometry['realized_sbw_x']:.3f} m"
        f"  (requested {geometry['requested_sbw_x']:.3f} m)"
    )
    print(
        f"    centroid y : {geometry['realized_sbw_y']:.3f} m"
        f"  (requested {geometry['requested_sbw_y']:.3f} m)"
    )
    print(
        f"    x faces    : {geometry['x_min']:.3f} – {geometry['x_max']:.3f} m"
    )
    print(
        f"    y faces    : {geometry['y_min']:.3f} – {geometry['y_max']:.3f} m"
    )


# ============================================================
# MAIN
# ============================================================

def main():
    args = parse_arguments()

    simulation_number = args.simulation
    output_directory = os.path.abspath(args.output)

    (
        simulation_id,
        wave_angle,
        Hs,
        Tp,
        sbw_x,
        sbw_y,
        D50,
        sbw_length_y,
    ) = load_simulation(simulation_number)

    print()
    print("=" * 60)
    print(f"GENERATING XBEACH SIMULATION {simulation_id}")
    print("=" * 60)
    print(f"\nWave angle : {wave_angle} deg")
    print(f"Hs         : {Hs} m")
    print(f"Tp         : {Tp} s")
    print(f"SBW x      : {sbw_x} m  (requested)")
    print(f"SBW y      : {sbw_y} m  (domain centre, requested)")
    print(f"SBW Ly     : {sbw_length_y} m  (requested)")
    print(f"D50        : {D50} m")
    print(f"\nOutput directory:\n{output_directory}")

    os.makedirs(output_directory, exist_ok=True)

    # Copy XBeach template FIRST
    copy_xbeach_template(output_directory)

    # Plain beach — grid must not see the SBW
    print("\nBuilding plain-beach bathymetry...")
    print(f"  shoreline_x = {shoreline_x} m  (z = 0)")
    print(f"  dry beach   ~ {Lx - shoreline_x:.0f} m  (to x = {Lx} m)")
    print(f"  slope       = 1/{1.0 / beach_slope:.0f}")
    print(f"  z range     = [{depth_offshore}, {max_elevation}] m")
    x, y, bathy = build_bathymetry()
    save_input_bathymetry_plot(x, y, bathy, output_directory)

    # Create XBeach grid (variable + SBW-band refinement)
    print("Creating XBeach grid...")
    xgr2d, ygr2d, zgr = create_xbeach_grid(x, y, bathy)
    save_regridded_bathymetry_plot(xgr2d, ygr2d, zgr, output_directory)

    # Extend grid
    print("Extending grid...")
    xgr2d, ygr2d, zgr = extend_grid(xgr2d, ygr2d, zgr)
    save_grid_resolution_plot(xgr2d, ygr2d, output_directory)

    # Stamp SBW onto the final grid (z and NE share one mask)
    print("Inserting submerged breakwater on the computational grid...")
    zgr, ne_field, sbw_geometry = insert_breakwater(
        xgr2d, ygr2d, zgr, sbw_x, sbw_y, sbw_length_y
    )
    print_sbw_geometry(sbw_geometry)
    save_extended_bathymetry_plot(xgr2d, ygr2d, zgr, output_directory)
    save_ne_layer_plot(xgr2d, ygr2d, ne_field, output_directory)

    # Build XBeach model
    print("Building XBeach model...")
    xb_setup = build_xbeach_model(
        xgr2d, ygr2d, zgr, ne_field, Hs, Tp, wave_angle, D50
    )

    # Write XBeach files
    write_model_files(xb_setup, output_directory)

    # Write simulation metadata
    write_simulation_info(
        output_directory,
        simulation_id,
        wave_angle,
        Hs,
        Tp,
        sbw_x,
        sbw_y,
        D50,
        sbw_length_y,
        sbw_geometry=sbw_geometry,
    )

    print()
    print("=" * 60)
    print(f"SIMULATION {simulation_id} SETUP COMPLETE")
    print("=" * 60)
    print(f"\nSimulation directory:\n{output_directory}")
    print("\nThe generator has finished.")
    print("XBeach has NOT been started.")


if __name__ == "__main__":
    main()
