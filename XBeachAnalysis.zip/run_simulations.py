"""
===============================================================
XBeach Sequential Simulation Runner
===============================================================

Purpose
-------
Runs a batch of XBeach simulations sequentially.

For each row in simulations.csv this script:

    1. Creates a simulation folder
    2. Runs the XBeach input-file generator
    3. Starts XBeach
    4. Waits for XBeach to finish
    5. Runs the XBeach post-processor
    6. Reads final erosion/accretion volumes
    7. Appends the result to master_results.csv
    8. Moves to the next simulation

The simulations are intentionally run ONE AT A TIME.

Expected input matrix:
    simulation_id,wave_angle,Hs,Tp,sbw_x,D50,sbw_length_y

Expected post-processing output:
    postprocessing/morphological_volume.csv
"""


# =============================================================
# 1. IMPORTS
# =============================================================

import csv
import re
import subprocess
import sys
import time
from pathlib import Path

import pandas as pd


# =============================================================
# 2. USER CONFIGURATION
# =============================================================

# Main XBeach analysis directory
# Keep all scripts and the input matrix inside this folder.
BASE_DIR = Path(
    r"C:\Users\alvarezd2022\Documents\VisualStudioCode\XBeachAnalysis"
)

# Input matrix
INPUT_MATRIX = BASE_DIR / "simulations.csv"

# Python script that generates each XBeach model
GENERATOR_SCRIPT = BASE_DIR / "generate_2D_setup_SBW.py"

# Python post-processing script
POSTPROCESSING_SCRIPT = BASE_DIR / "post_processing_2D.py"

# XBeach template/package directory
TEMPLATE_DIR = BASE_DIR / "XBeach_1.24.6057_Halloween_win64_netcdf"

# Folder containing all simulation results
RESULTS_DIR = BASE_DIR / "results"

# Master output table
MASTER_RESULTS = BASE_DIR / "master_results.csv"

# Stop the entire batch if one simulation fails.
#
# True  = stop immediately so the failure can be debugged
# False = record the failure and continue to the next row
STOP_ON_ERROR = True


# =============================================================
# 3. HELPER FUNCTIONS
# =============================================================

def print_header(text):
    """Print a clear section header."""
    print()
    print("=" * 70)
    print(text)
    print("=" * 70)


def find_xbeach_executable():
    """
    Find xbeach.exe inside the template directory.

    The relative path is preserved so that the same executable
    location can be used inside each copied simulation folder.
    """
    executables = list(TEMPLATE_DIR.rglob("xbeach.exe"))

    if not executables:
        raise FileNotFoundError(
            f"Could not find xbeach.exe inside:\n{TEMPLATE_DIR}"
        )

    if len(executables) > 1:
        print("WARNING: Multiple xbeach.exe files were found.")
        print(f"Using: {executables[0]}")

    return executables[0]


def initialize_master_results():
    """Start a fresh master results file for this batch."""
    MASTER_RESULTS.parent.mkdir(parents=True, exist_ok=True)

    columns = [
        "simulation_id",
        "wave_angle",
        "Hs",
        "Tp",
        "sbw_x",
        "D50",
        "sbw_length_y",
        "total_erosion_m3",
        "total_accretion_m3",
    ]

    with open(MASTER_RESULTS, "w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(columns)


def append_master_result(simulation, erosion, accretion):
    """Append one completed simulation to master_results.csv."""
    row = [
        int(simulation["simulation_id"]),
        float(simulation["wave_angle"]),
        float(simulation["Hs"]),
        float(simulation["Tp"]),
        float(simulation["sbw_x"]),
        float(simulation["D50"]),
        float(simulation["sbw_length_y"]),
        float(erosion),
        float(accretion),
    ]

    with open(MASTER_RESULTS, "a", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(row)


def progress_bar(fraction, width=28):
    """Return a simple ASCII progress bar string."""
    fraction = max(0.0, min(1.0, float(fraction)))
    filled = int(round(width * fraction))
    bar = "#" * filled + "-" * (width - filled)
    return f"[{bar}] {100.0 * fraction:5.1f}%"


def read_tstop(simulation_dir):
    """
    Read tstop from params.txt if present.
    Falls back to 7200 s (the value set in the generator).
    """
    params_file = simulation_dir / "params.txt"
    if not params_file.is_file():
        return 7200.0

    try:
        text = params_file.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return 7200.0

    match = re.search(
        r"^\s*tstop\s*=\s*([0-9.+-Ee]+)",
        text,
        flags=re.MULTILINE | re.IGNORECASE,
    )
    if match:
        try:
            return float(match.group(1))
        except ValueError:
            pass

    return 7200.0


def parse_model_time_from_log(log_file):
    """
    Try to extract the latest model time (seconds) from xbeach.log.

    XBeach log formats vary; several common patterns are tried.
    Returns None if nothing usable is found.
    """
    if not log_file.is_file():
        return None

    try:
        # Read only the tail to keep this cheap on long runs
        with open(log_file, "rb") as file:
            file.seek(0, 2)
            size = file.tell()
            file.seek(max(0, size - 50000), 0)
            tail = file.read().decode("utf-8", errors="replace")
    except OSError:
        return None

    patterns = [
        r"(?:time|t)\s*=\s*([0-9.+-Ee]+)\s*s",
        r"t\s*=\s*([0-9.+-Ee]+)",
        r"Time\s+([0-9.+-Ee]+)",
    ]

    latest = None
    for pattern in patterns:
        for match in re.finditer(pattern, tail, flags=re.IGNORECASE):
            try:
                value = float(match.group(1))
            except ValueError:
                continue
            if latest is None or value > latest:
                latest = value

    return latest


def run_command(command, working_directory, log_file, label=None):
    """
    Run an external command and save stdout/stderr to a log file.
    The command is waited on before this function returns.
    """
    print()
    if label:
        print(f"{label}")
    print("Running:")
    print(
        " ".join(
            f'"{x}"' if " " in str(x) else str(x) for x in command
        )
    )
    print(f"Working directory: {working_directory}")
    print(f"Log file: {log_file}")

    with open(log_file, "w", encoding="utf-8", errors="replace") as log:
        result = subprocess.run(
            command,
            cwd=working_directory,
            stdout=log,
            stderr=subprocess.STDOUT,
            check=False,
        )

    if result.returncode != 0:
        raise RuntimeError(
            f"Command failed with exit code {result.returncode}.\n"
            f"See log:\n{log_file}"
        )

    return result


def run_generator(simulation_id, simulation_dir):
    """Generate the XBeach model files for one simulation."""
    log_file = simulation_dir / "generator.log"

    command = [
        sys.executable,
        str(GENERATOR_SCRIPT),
        "--simulation",
        str(simulation_id),
        "--output",
        str(simulation_dir),
    ]

    run_command(
        command,
        BASE_DIR,
        log_file,
        label="Generating model files...",
    )


def run_xbeach(simulation_dir, xbeach_relative_path):
    """
    Run XBeach in the simulation directory and show live progress.

    Progress is based on:
      1. Model time parsed from xbeach.log (when available)
      2. Wall-clock elapsed time as a fallback display

    Running with cwd=simulation_dir is important because XBeach
    expects params.txt and the model files in its working folder.
    """
    executable = simulation_dir / xbeach_relative_path

    if not executable.is_file():
        raise FileNotFoundError(
            "XBeach executable was not found in simulation folder:\n"
            f"{executable}"
        )

    log_file = simulation_dir / "xbeach.log"
    tstop = read_tstop(simulation_dir)

    print()
    print("Running XBeach...")
    print(f"  Executable : {executable}")
    print(f"  Working dir: {simulation_dir}")
    print(f"  Log file   : {log_file}")
    print(f"  tstop      : {tstop:.1f} s")
    print()

    start_time = time.perf_counter()

    with open(log_file, "w", encoding="utf-8", errors="replace") as log:
        process = subprocess.Popen(
            [str(executable)],
            cwd=simulation_dir,
            stdout=log,
            stderr=subprocess.STDOUT,
        )

        last_print = 0.0
        try:
            while True:
                return_code = process.poll()
                now = time.perf_counter()
                elapsed = now - start_time

                # Update the progress line about once per second
                if now - last_print >= 1.0 or return_code is not None:
                    model_time = parse_model_time_from_log(log_file)

                    if model_time is not None and tstop > 0:
                        fraction = min(model_time / tstop, 1.0)
                        status = (
                            f"  XBeach {progress_bar(fraction)}  "
                            f"model t = {model_time:.1f}/{tstop:.1f} s  "
                            f"elapsed = {elapsed:.0f} s"
                        )
                    else:
                        # No model time in the log yet — show elapsed only
                        status = (
                            f"  XBeach running...  "
                            f"elapsed = {elapsed:.0f} s  "
                            f"(waiting for log progress)"
                        )

                    # Pad with spaces so previous longer lines are cleared
                    print(f"\r{status:<100}", end="", flush=True)
                    last_print = now

                if return_code is not None:
                    break

                time.sleep(0.5)
        except KeyboardInterrupt:
            process.terminate()
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
            print()
            raise

    print()  # finish the \r progress line

    runtime = time.perf_counter() - start_time

    if process.returncode != 0:
        raise RuntimeError(
            f"XBeach failed with exit code {process.returncode}.\n"
            f"See log:\n{log_file}"
        )

    print(f"XBeach finished. Runtime: {runtime:.2f} seconds")
    return runtime


def verify_xbeach_output(simulation_dir):
    """Confirm that XBeach produced xboutput.nc."""
    output_file = simulation_dir / "xboutput.nc"

    if not output_file.is_file():
        raise FileNotFoundError(
            "XBeach finished, but xboutput.nc was not found:\n"
            f"{output_file}"
        )

    if output_file.stat().st_size == 0:
        raise RuntimeError(
            f"xboutput.nc exists but is empty:\n{output_file}"
        )

    print(f"Verified XBeach output: {output_file}")


def run_postprocessor(simulation_dir):
    """Run the postprocessor for the current simulation."""
    log_file = simulation_dir / "postprocessor.log"

    command = [
        sys.executable,
        str(POSTPROCESSING_SCRIPT),
        "--simulation-dir",
        str(simulation_dir),
    ]

    run_command(
        command,
        BASE_DIR,
        log_file,
        label="Running post-processor...",
    )


def read_final_morphological_volume(simulation_dir):
    """Read the final row from morphological_volume.csv."""
    volume_file = (
        simulation_dir / "postprocessing" / "morphological_volume.csv"
    )

    if not volume_file.is_file():
        raise FileNotFoundError(
            "Postprocessor did not produce:\n" f"{volume_file}"
        )

    data = pd.read_csv(volume_file)

    if data.empty:
        raise RuntimeError(
            f"Morphological volume CSV is empty:\n{volume_file}"
        )

    required_columns = {"accretion_volume_m3", "erosion_volume_m3"}
    missing = required_columns - set(data.columns)

    if missing:
        raise ValueError(
            "Morphological volume CSV is missing columns:\n"
            f"{sorted(missing)}"
        )

    final_row = data.iloc[-1]
    accretion = float(final_row["accretion_volume_m3"])
    erosion = float(final_row["erosion_volume_m3"])

    return erosion, accretion


# =============================================================
# 4. MAIN BATCH PROCESS
# =============================================================

def main():
    print_header("XBeach Sequential Simulation Runner")

    # ---------------------------------------------------------
    # Check required files/folders
    # ---------------------------------------------------------

    required_paths = {
        "Input matrix": INPUT_MATRIX,
        "Generator script": GENERATOR_SCRIPT,
        "Postprocessor": POSTPROCESSING_SCRIPT,
        "XBeach template": TEMPLATE_DIR,
    }

    for name, path in required_paths.items():
        if not path.exists():
            raise FileNotFoundError(f"{name} was not found:\n{path}")

    # ---------------------------------------------------------
    # Load simulation matrix
    # ---------------------------------------------------------

    simulations = pd.read_csv(INPUT_MATRIX)

    required_columns = [
        "simulation_id",
        "wave_angle",
        "Hs",
        "Tp",
        "sbw_x",
        "D50",
        "sbw_length_y",
    ]

    missing_columns = [
        column
        for column in required_columns
        if column not in simulations.columns
    ]

    if missing_columns:
        raise ValueError(
            "The simulation matrix is missing columns:\n"
            f"{missing_columns}"
        )

    if simulations.empty:
        raise ValueError("The simulation matrix contains no simulations.")

    # ---------------------------------------------------------
    # Locate XBeach executable in template
    # ---------------------------------------------------------

    template_executable = find_xbeach_executable()
    xbeach_relative_path = template_executable.relative_to(TEMPLATE_DIR)

    print()
    print(f"XBeach executable: {template_executable}")
    print(f"Relative path: {xbeach_relative_path}")

    # ---------------------------------------------------------
    # Prepare output folders
    # ---------------------------------------------------------

    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    initialize_master_results()

    print()
    print(f"Input matrix: {INPUT_MATRIX}")
    print(f"Number of simulations: {len(simulations)}")
    print(f"Results directory: {RESULTS_DIR}")
    print(f"Master results: {MASTER_RESULTS}")

    # ---------------------------------------------------------
    # Run simulations sequentially
    # ---------------------------------------------------------

    total_start = time.perf_counter()
    n_sims = len(simulations)

    for index, simulation in simulations.iterrows():
        simulation_id = int(simulation["simulation_id"])
        simulation_dir = RESULTS_DIR / f"SIM_{simulation_id:03d}"
        sim_number = index + 1
        batch_fraction = (sim_number - 1) / n_sims

        print_header(
            f"SIMULATION {simulation_id}  "
            f"[{sim_number}/{n_sims}]  "
            f"batch {progress_bar(batch_fraction)}"
        )

        print("Input parameters:")
        print(f"    Wave angle = {simulation['wave_angle']}")
        print(f"    Hs         = {simulation['Hs']} m")
        print(f"    Tp         = {simulation['Tp']} s")
        print(f"    SBW X      = {simulation['sbw_x']} m")
        print(f"    SBW Ly     = {simulation['sbw_length_y']} m")
        print(f"    D50        = {simulation['D50']} m")

        simulation_start = time.perf_counter()

        try:
            # Create simulation directory
            simulation_dir.mkdir(parents=True, exist_ok=True)

            # Step 1 — Generate XBeach model
            print_header(f"SIM {simulation_id}: GENERATING MODEL")
            run_generator(simulation_id, simulation_dir)

            # Step 2 — Run XBeach
            print_header(f"SIM {simulation_id}: RUNNING XBEACH")
            run_xbeach(simulation_dir, xbeach_relative_path)

            # Step 3 — Verify XBeach output
            verify_xbeach_output(simulation_dir)

            # Step 4 — Post-process
            print_header(f"SIM {simulation_id}: POST-PROCESSING")
            run_postprocessor(simulation_dir)

            # Step 5 — Extract final erosion/accretion
            print_header(f"SIM {simulation_id}: EXTRACTING RESULTS")
            erosion, accretion = read_final_morphological_volume(
                simulation_dir
            )

            # Step 6 — Append to master CSV
            append_master_result(simulation, erosion, accretion)

            simulation_runtime = time.perf_counter() - simulation_start

            print()
            print(f"FINAL EROSION:   {erosion:.6f} m^3")
            print(f"FINAL ACCRETION: {accretion:.6f} m^3")
            print(f"Simulation runtime: {simulation_runtime:.2f} seconds")
            print()
            print(f"Simulation {simulation_id} completed successfully.")
            print(
                f"Batch progress: {progress_bar(sim_number / n_sims)}  "
                f"[{sim_number}/{n_sims}]"
            )

        except Exception as error:
            print()
            print(f"SIMULATION {simulation_id} FAILED")
            print()
            print(error)

            # Write a failure marker for easy debugging
            failure_file = simulation_dir / "FAILED.txt"
            failure_file.write_text(str(error), encoding="utf-8")

            if STOP_ON_ERROR:
                print()
                print("STOP_ON_ERROR=True. The batch has been stopped.")
                raise

            print("Continuing to the next simulation...")

    # ---------------------------------------------------------
    # Batch complete
    # ---------------------------------------------------------

    total_runtime = time.perf_counter() - total_start

    print_header("BATCH COMPLETE")
    print(f"Completed simulations: {len(simulations)}")
    print(f"Total runtime: {total_runtime:.2f} seconds")
    print()
    print(f"Master results saved to:\n{MASTER_RESULTS}")


# =============================================================
# 5. START PROGRAM
# =============================================================

if __name__ == "__main__":
    main()
