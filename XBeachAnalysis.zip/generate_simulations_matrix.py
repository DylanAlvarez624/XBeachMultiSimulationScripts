"""
===============================================================
Generate simulations.csv for the XBeach batch runner
===============================================================

Creates a full-factorial (or custom) input matrix with columns:

    simulation_id, wave_angle, Hs, Tp, sbw_x, D50, sbw_length_y

Wave-angle symmetry
-------------------
Only one side of shore-normal is sampled. If 270° is shore-normal,
use angles <= 270 (e.g. 270, 255, 240). Do not also include the
mirror angles (285, 300, …).

Usage
-----
    python generate_simulations_matrix.py

Edit the PARAMETER LEVELS section below to change the design.
"""

from itertools import product
from pathlib import Path

import pandas as pd


# ============================================================
# OUTPUT LOCATION
# ============================================================

# Where to write simulations.csv
# (should match INPUT_MATRIX used by the generator and runner)
OUTPUT_CSV = Path(
    r"C:\Users\alvarezd2022\Documents\VisualStudioCode"
    r"\XBeachAnalysis\simulations.csv"
)


# ============================================================
# PARAMETER LEVELS  ← edit this section
# ============================================================

# Wave direction [deg]
# 270 = shore-normal (typical with alfa = 0)
# Only one side of normal is included (symmetry).
WAVE_ANGLE = [270, 255, 240, 225]          # normal, 15°, 30°, 45°

# Significant wave height [m]
HS = [1.0, 2.0, 4.0, 8.0]

# Peak period [s]
TP = [4.0, 8.0, 10.0]

# Breakwater cross-shore centroid [m]
# (x = 0 is offshore, x increases toward shore)
SBW_X = [100.0, 150.0, 200.0, 250.0]

# Sediment median diameter [m]
# 0.0002 m = 0.2 mm
D50 = [0.00025]

# Breakwater alongshore length [m]
# (centroid is fixed at domain centre Ly/2)
SBW_LENGTH_Y = [50.0, 100.0]


# ============================================================
# BUILD MATRIX
# ============================================================

def build_matrix():
    """Create a full-factorial design from the levels above."""

    rows = []
    sim_id = 1

    for wave_angle, hs, tp, sbw_x, d50, sbw_ly in product(
        WAVE_ANGLE,
        HS,
        TP,
        SBW_X,
        D50,
        SBW_LENGTH_Y,
    ):
        rows.append(
            {
                "simulation_id": sim_id,
                "wave_angle": wave_angle,
                "Hs": hs,
                "Tp": tp,
                "sbw_x": sbw_x,
                "D50": d50,
                "sbw_length_y": sbw_ly,
            }
        )
        sim_id += 1

    return pd.DataFrame(rows)


def main():
    df = build_matrix()

    OUTPUT_CSV.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(OUTPUT_CSV, index=False)

    n = len(df)
    print("=" * 60)
    print("simulations.csv generated")
    print("=" * 60)
    print(f"File      : {OUTPUT_CSV}")
    print(f"Runs      : {n}")
    print()
    print("Levels used:")
    print(f"  wave_angle   : {WAVE_ANGLE}")
    print(f"  Hs           : {HS}")
    print(f"  Tp           : {TP}")
    print(f"  sbw_x        : {SBW_X}")
    print(f"  D50          : {D50}")
    print(f"  sbw_length_y : {SBW_LENGTH_Y}")
    print()
    print("First few rows:")
    print(df.head(10).to_string(index=False))
    print()
    if n > 10:
        print(f"... ({n - 10} more rows)")
    print("=" * 60)


if __name__ == "__main__":
    main()
